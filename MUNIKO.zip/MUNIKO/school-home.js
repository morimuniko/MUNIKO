function homeStaffEscape(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

async function refreshHomeStaff() {
    const status = document.getElementById('home-staff-status');
    try {
        const client = await window.schoolSupabase.client();
        const { data: staff, error } = await client.from('school_staff').select('id,staff_type,full_name,leadership_position,leadership_title').order('full_name');
        if (error) throw error;
        const result = { staff: staff || [] };
        const groups = {
            teaching: result.staff.filter(member => member.staff_type === 'teaching'),
            non_teaching: result.staff.filter(member => member.staff_type === 'non_teaching')
        };
        for (const [type, members] of Object.entries(groups)) {
            const target = document.querySelector(`[data-home-staff="${type}"]`);
            const count = document.querySelector(`[data-staff-count="${type}"]`);
            if (count) count.textContent = members.length;
            if (target) target.innerHTML = members.length
                ? members.slice(0, 3).map(member => `<p>${homeStaffEscape(member.full_name)}${type === 'teaching' && member.leadership_position === 'Staff Leader' ? ` <span>· ${homeStaffEscape(member.leadership_title || 'Staff Leader')}</span>` : ''}</p>`).join('')
                : '<p>Staff directory is being updated.</p>';
            const menu = document.getElementById(`${type}-dropdown-links`);
            if (menu) menu.innerHTML = members.length
                ? members.slice(0, 8).map(member => `<li><span class="staff-dropdown-name">${homeStaffEscape(member.full_name)}</span></li>`).join('')
                : '<li><span class="staff-dropdown-name">No staff profiles listed</span></li>';
        }
        if (status) status.textContent = `${result.staff.length} school staff profiles`;
    } catch (error) {
        if (status) status.textContent = 'Staff directory unavailable';
        document.querySelectorAll('[data-home-staff]').forEach(target => { target.innerHTML = '<p>View the staff directories for current information.</p>'; });
    }
}

refreshHomeStaff();
window.setInterval(refreshHomeStaff, 60000);
