const state = { csrfToken: null, admin: null };
const notice = document.querySelector('#borrowing-notice');
const loginForm = document.querySelector('#login-form');
const adminControls = document.querySelector('#admin-controls');
const loanRows = document.querySelector('#loan-rows');
const checkForm = document.querySelector('#check-form');
const lookupResult = document.querySelector('#lookup-result');

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
    })[character]);
}

function showNotice(message, isError = false) {
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.classList.add('visible');
}

async function request(action, { method = 'GET', data } = {}) {
    return window.schoolSupabase.api(action, { method, data });
}

function parseLocalDate(value) {
    if (!value) return null;
    const normalized = value.includes('T') ? value : value.replace(' ', 'T');
    const match = normalized.match(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})(?::\d{2})?$/);
    if (!match) return new Date(normalized);
    const [year, month, day] = match[1].split('-').map(Number);
    const [hour, minute] = match[2].split(':').map(Number);
    return new Date(Date.UTC(year, month - 1, day, hour, minute));
}

function formatTimestamp(value, use12Hour = true) {
    const date = parseLocalDate(value);
    if (!date || Number.isNaN(date.getTime())) return value || '—';
    const dateOptions = { timeZone: 'UTC' };
    const dateText = new Intl.DateTimeFormat('en-GB', {
        ...dateOptions, day: '2-digit', month: 'long', year: 'numeric',
    }).format(date);
    const weekday = new Intl.DateTimeFormat('en-GB', {
        ...dateOptions, weekday: 'long',
    }).format(date);
    const timeText = new Intl.DateTimeFormat('en-GB', {
        ...dateOptions, hour: '2-digit', minute: '2-digit', hour12: use12Hour,
    }).format(date).toLowerCase();
    return `${dateText}, ${weekday}, at ${timeText}`;
}

function setAdmin(admin) {
    state.admin = admin;
    loginForm.hidden = Boolean(admin);
    adminControls.hidden = !admin;
    const status = document.querySelector('#admin-state');
    status.textContent = admin ? `Signed in: ${admin}` : 'Signed out';
    status.classList.toggle('signed-in', Boolean(admin));
}

function renderLoans(loans = []) {
    loanRows.innerHTML = loans.length ? loans.map((loan) => `
        <tr>
            <td><strong>${escapeHtml(loan.serial_number)}</strong><span class="book-author">${escapeHtml(loan.title)}</span></td>
            <td>${state.admin ? `${escapeHtml(loan.borrower_name)}${loan.borrower_class ? `<span class="book-author">${escapeHtml(loan.borrower_class)}</span>` : ''}` : '—'}</td>
            <td>${escapeHtml(formatTimestamp(loan.borrowed_at))}</td>
            <td>${loan.returned_at ? `${escapeHtml(formatTimestamp(loan.returned_at, false))}` : '<span class="availability out">Not yet returned</span>'}</td>
            <td>${loan.returned_at ? '<span class="availability">Cleared</span>' : state.admin ? `<button class="row-action" data-return-loan="${Number(loan.id)}" type="button">Record return</button>` : '<span class="availability out">On loan</span>'}</td>
        </tr>`).join('') : '<tr><td class="empty-state" colspan="5">No borrowing records have been recorded.</td></tr>';
}

function renderAvailableBooks(books = []) {
    const available = books.filter((book) => Boolean(book.available));
    document.querySelector('#borrow-book').innerHTML = available.length
        ? available.map((book) => `<option value="${Number(book.id)}">${escapeHtml(book.serial_number)} · ${escapeHtml(book.title)}</option>`).join('')
        : '<option value="">No available books</option>';
}

async function loadDashboard() {
    const data = await request('dashboard');
    state.csrfToken = data.csrf_token || state.csrfToken;
    setAdmin(data.admin || null);
    renderLoans(data.loans || []);
    renderAvailableBooks(data.books || []);
}

checkForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const serial = document.querySelector('#serial-check').value.trim();
    lookupResult.classList.remove('error');
    lookupResult.textContent = 'Checking the register…';
    try {
        const { book } = await request(`check&serial=${encodeURIComponent(serial)}`);
        lookupResult.textContent = book.available
            ? `The book with serial number ${book.serial_number} is available to borrow.`
            : `The book with serial number ${book.serial_number} is currently on loan. Borrower details are available to authorized administrators.`;
    } catch (error) {
        lookupResult.textContent = error.message;
        lookupResult.classList.add('error');
    }
});

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
        const result = await request('login', {
            method: 'POST',
            data: Object.fromEntries(new FormData(loginForm).entries()),
        });
        state.csrfToken = result.csrf_token;
        await loadDashboard();
        showNotice(`Signed in as ${result.admin}.`);
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#logout-button').addEventListener('click', async () => {
    try {
        await request('logout', { method: 'POST', data: {} });
        state.csrfToken = null;
        setAdmin(null);
        showNotice('Signed out.');
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#borrow-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const data = Object.fromEntries(new FormData(form).entries());
        data.book_id = Number(data.book_id);
        await request('borrow', { method: 'POST', data });
        form.reset();
        showNotice('Borrowing recorded. The date and time were captured automatically.');
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

loanRows.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-return-loan]');
    if (!button) return;
    button.disabled = true;
    try {
        await request('return', { method: 'POST', data: { loan_id: Number(button.dataset.returnLoan) } });
        showNotice('Return recorded. The clearance date and time were captured automatically.');
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
        button.disabled = false;
    }
});

loadDashboard().catch((error) => {
    showNotice(`${error.message} Check the Supabase connection, schema, and Auth role.`, true);
    loanRows.innerHTML = '<tr><td class="empty-state" colspan="5">Borrowing history is unavailable.</td></tr>';
    document.querySelector('#borrow-book').innerHTML = '<option value="">Inventory unavailable</option>';
});