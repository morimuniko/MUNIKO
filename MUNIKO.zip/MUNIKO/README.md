# Nyabikongori Senior School Website

This project uses plain HTML/CSS/JavaScript in the browser and Supabase for database, authentication, and profile-photo storage. PHP remains only for a small config endpoint that reads the local public anon key from `config/.env`; it does not connect to MySQL. Never use a Supabase `service_role` key in this project.

## Pages and data flows

| Page/script | What it manages | Supabase tables/RPCs |
| --- | --- | --- |
| `index.html`, `management staff.html`, `school-home.js` | Home preview and staff dropdowns | `school_staff` |
| `teaching-staff.html`, `non-teaching-staff.html`, `school-staff.js` | Public staff lists and print registers | `school_staff`, Storage `profile-photos` |
| `staff-admin.html`, `staff-admin.js` | Admin sign-in, staff add/edit/delete | Supabase Auth, `user_roles`, `school_staff`, Storage |
| `administration.html`, `admissions.js` | Student registration, editing, searching, archive, print | `students`, `removed_students`, `admission_sequences`, RPCs |
| `accounts office.html`, `accounts-office.js` | Clerk profile, school-fee payments, receipts and print | Supabase Auth, `accounts_clerk`, `fee_payments`, RPCs, Storage |
| `Books Categories.html`, `books-categories.js` | Public catalog, categories, admin book/category entry | `library_categories`, `books`, `list_public_books()` |
| `Borrowed Books.html`, `borrowed-books.js` | Public availability/history, admin borrow/return | `loans`, `books`, `record_book_loan()`, `record_book_return()`, `list_public_loans()` |
| `staff profiles.html`, `staff-profiles.js` | Library leadership profiles | `library_staff_profiles`, Storage |
| `library.js` | Shared library dashboard functionality | Same library tables/RPCs |

Existing print behavior remains in the page scripts: staff tables, admissions records, fee receipts, clerk profiles, and library reports still use `window.print()` with print styles.

## Connect Supabase

1. In your Supabase dashboard, open **SQL Editor** for project `mngxbcmpevahffezvojj`.
2. Run `supabase/schema.sql` first. Then run `supabase/functions-and-grants.sql`, followed by `supabase/dashboard-functions.sql`.
3. Open `config/.env` and replace `PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE` with your project's **anon / publishable public key**. The project URL is already entered. Do not put a service-role/secret key here. `config/.env` is git-ignored and blocked by Apache; `config/supabase-config.php` returns only the project URL and anon key to the browser.
4. Serve this folder through Apache/PHP, for example in XAMPP at `http://localhost/MUNIKO/`. Do not open pages using `file:///`. PHP must run for the config endpoint.
5. Supabase Auth users must be created in **Authentication > Users**. Use email/password. Disable public signups in Auth settings after setting up the required users.
6. Copy each user's UUID from Authentication > Users. In the SQL Editor, assign the role needed for the pages they use:

   ```sql
   insert into public.user_roles (user_id, role)
   values ('AUTH_USER_UUID_HERE', 'admin');

   insert into public.user_roles (user_id, role)
   values ('CLERK_AUTH_USER_UUID_HERE', 'accounts_clerk');
   ```

   Run only the role insert(s) appropriate for your users. Admin users can manage staff, admissions, and library records. The accounts-clerk role can manage the clerk profile and fee payments. A person needing both sets of permissions can have both role rows. Do this as the Supabase project owner, never from browser JavaScript.
7. Sign in at `staff-admin.html` or `administration.html` with the admin email/password. Sign in at `accounts office.html` with the clerk email/password. On first clerk login, complete the clerk profile form.
8. The browser checks its connection by selecting one public staff ID and logs **Connected to Supabase** in the browser console. If it fails, check the anon key, SQL setup, RLS, and that the site is running via PHP.

## RLS and access choices

Row Level Security is enabled for every application table. Public visitors can read school staff, library categories, library leadership profiles, and limited public library RPC results. The public loan RPC intentionally omits borrower names/classes. Student and removed-student rows require `admin`. Fee rows and clerk profiles require the accounts-clerk or admin role. All writes require authenticated role policies; admission numbering, student archival, payments, and library borrowing/returns use database functions so the operation and sequence update are atomic. The anon key is safe to expose only because RLS restricts what it can do.

The `profile-photos` Storage bucket is public for displaying photos, but uploads/updates/deletes require an authenticated admin or the clerk's own UID-prefixed folder. Uploads are limited to JPG/PNG/WEBP and 3 MB.

## Existing MySQL records

Running the Supabase SQL creates an empty Supabase schema; it does **not** copy existing MySQL rows or files. Export MySQL tables as CSV and import matching tables through Supabase **Table Editor > Import data from CSV**. Upload old profile photos to the `profile-photos` bucket and update each row's `photo_path` to its Storage object path. Do not import password hashes: create users in Supabase Auth and assign roles using their Auth UUIDs. Keep a backup of the MySQL database and uploads until you verify the migration.

## Quick tests

- Open `index.html` through PHP: staff dropdown counts/names load; public teaching/non-teaching pages show current rows.
- Sign in as admin: add, edit, and delete a staff member; verify duplicate names are rejected, then refresh public pages.
- Register a student and verify the generated `ADM/YYYY/NNN` number; edit and archive one and verify dashboard counts/history.
- Sign in as clerk: complete the profile and photo, record a positive fee payment, and verify its receipt in payment search. Blank student/admission/form or a zero amount must not create a row. Test receipt print, profile print, and payment-list print.
- In the library, add a category/book, check its public availability, borrow and return as admin, and verify public status does not reveal borrower identity.
- Sign out and retry writes; unauthenticated or wrong-role writes should be rejected by Supabase RLS.

For beginner setup and database diagrams, see [the accounts office guide](docs/accounts-office-guide.md) and [the staff management guide](docs/staff-management-guide.md).
