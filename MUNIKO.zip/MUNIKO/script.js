const navigation = document.querySelector('nav');
const navWrap = document.querySelector('.nav-wrap');

if (navigation && navWrap) {
    const menuButton = navWrap.querySelector('.menu-button') || document.createElement('button');
    menuButton.className = 'menu-button';
    menuButton.type = 'button';
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-controls', 'main-navigation');
    menuButton.textContent = 'Menu';
    navigation.id = 'main-navigation';
    if (!menuButton.isConnected) navWrap.insertBefore(menuButton, navigation);

    menuButton.addEventListener('click', () => {
        const isOpen = navigation.classList.toggle('open');
        menuButton.setAttribute('aria-expanded', String(isOpen));
        menuButton.textContent = isOpen ? 'Close' : 'Menu';
    });

    navigation.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            navigation.classList.remove('open');
            menuButton.setAttribute('aria-expanded', 'false');
            menuButton.textContent = 'Menu';
        });
    });
}

document.querySelectorAll('.dropdown-toggle[aria-controls]').forEach((toggle) => {
    const menu = document.getElementById(toggle.getAttribute('aria-controls'));
    if (!menu) return;

    const setExpanded = (expanded) => {
        toggle.setAttribute('aria-expanded', String(expanded));
        const menuLabel = toggle.getAttribute('data-menu-label') || toggle.getAttribute('aria-label')?.replace(/^(Show|Hide)\s+/, '') || 'navigation links';
        toggle.setAttribute('aria-label', `${expanded ? 'Hide' : 'Show'} ${menuLabel}`);
        menu.hidden = !expanded;
    };

    toggle.addEventListener('click', () => {
        setExpanded(toggle.getAttribute('aria-expanded') !== 'true');
    });

    menu.addEventListener('click', (event) => {
        if (event.target.closest('a')) setExpanded(false);
    });

    document.addEventListener('click', (event) => {
        const dropdown = toggle.closest('.nav-dropdown, .nav-subdropdown, .management-nav-dropdown');
        if (dropdown && !dropdown.contains(event.target)) setExpanded(false);
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
            setExpanded(false);
            toggle.focus();
        }
    });
});

const progressBar = document.createElement('div');
progressBar.className = 'scroll-progress';
progressBar.setAttribute('aria-hidden', 'true');
document.body.append(progressBar);

const updateScrollProgress = () => {
    const pageHeight = document.documentElement.scrollHeight - window.innerHeight;
    progressBar.style.transform = `scaleX(${pageHeight > 0 ? window.scrollY / pageHeight : 0})`;
};

window.addEventListener('scroll', updateScrollProgress, { passive: true });
updateScrollProgress();

const sections = document.querySelectorAll('main section[id]');
const sectionLinks = document.querySelectorAll('nav a[href^="#"]');
const revealItems = document.querySelectorAll('.section-heading, .about-grid, .staff-card, .library-content, .contact-grid');

revealItems.forEach((item) => item.classList.add('reveal'));

if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    revealItems.forEach((item) => revealObserver.observe(item));

    const activeSectionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            sectionLinks.forEach((link) => {
                link.toggleAttribute('aria-current', link.getAttribute('href') === `#${entry.target.id}`);
            });
        });
    }, { rootMargin: '-35% 0px -55% 0px' });

    sections.forEach((section) => activeSectionObserver.observe(section));
} else {
    revealItems.forEach((item) => item.classList.add('visible'));
}

const hero = document.querySelector('.hero');
if (hero && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.addEventListener('scroll', () => {
        hero.style.backgroundPosition = `center ${50 + window.scrollY * 0.03}%`;
    }, { passive: true });
}