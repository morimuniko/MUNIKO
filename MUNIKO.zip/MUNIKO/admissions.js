const state = { csrfToken: '', students: [], admin: '' };
const fieldNames = ['first_name', 'middle_name', 'last_name', 'gender', 'date_of_birth', 'guardian_name', 'guardian_phone', 'previous_school', 'year_completed', 'certificate_name', 'index_number', 'marks_or_grade', 'class_completed'];

async function api(action, { method = 'GET', data, query = '' } = {}) {
    return window.schoolSupabase.api(action, { method, data, query });
}

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function fullName(student) {
    return [student.first_name, student.middle_name, student.last_name].filter(Boolean).join(' ');
}

function showNotice(message, isError = false) {
    const notice = document.getElementById('notice');
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.hidden = false;
    window.clearTimeout(showNotice.timeout);
    showNotice.timeout = window.setTimeout(() => { notice.hidden = true; }, 6500);
}

function showLogin() {
    document.getElementById('login-screen').hidden = false;
    document.getElementById('app-shell').hidden = true;
    document.getElementById('login-form').hidden = false;
    document.getElementById('login-username').focus();
}

async function enterDashboard(summary) {
    summary = summary || await api('admission_dashboard');
    state.admin = summary.admin;
    state.csrfToken = summary.csrf_token || state.csrfToken;
    document.getElementById('admin-name').textContent = state.admin;
    document.getElementById('login-screen').hidden = true;
    document.getElementById('app-shell').hidden = false;
    renderSummary(summary);
    await loadStudents();
}

function renderSummary(summary) {
    document.getElementById('total-students').textContent = summary.total_students;
    document.getElementById('male-students').textContent = summary.male_students;
    document.getElementById('female-students').textContent = summary.female_students;
    const rows = summary.recent_students.map(student => `<tr>
        <td class="admission-code">${escapeHtml(student.admission_number)}</td>
        <td><strong>${escapeHtml(fullName(student))}</strong></td>
        <td>${escapeHtml(student.gender)}</td>
        <td>${escapeHtml(student.previous_school)}</td>
        <td><button class="button secondary small" data-action="view" data-id="${student.id}">View</button></td>
    </tr>`).join('');
    document.getElementById('recent-rows').innerHTML = rows || '<tr><td colspan="5" class="empty-state">No students registered yet.</td></tr>';
}

async function refreshSummary() {
    const summary = await api('admission_dashboard');
    renderSummary(summary);
}

async function loadStudents() {
    const search = document.getElementById('student-search').value.trim();
    const gender = document.getElementById('gender-filter').value;
    const query = new URLSearchParams({ search, gender }).toString();
    const result = await api('students', { query: `&${query}` });
    state.students = result.students;
    renderStudentTables();
    updatePrintOptions();
}

function studentRow(student, removable = false) {
    const actions = removable
        ? `<button class="button danger small" data-action="remove" data-id="${student.id}">Remove</button>`
        : `<button class="button secondary small" data-action="view" data-id="${student.id}">View</button>
           <button class="button secondary small" data-action="edit" data-id="${student.id}">Edit</button>
           <button class="button danger small" data-action="remove" data-id="${student.id}">Remove</button>`;
    return `<tr>
        <td class="admission-code">${escapeHtml(student.admission_number)}</td>
        <td><strong>${escapeHtml(fullName(student))}</strong></td>
        <td>${escapeHtml(student.gender)}</td>
        <td>${escapeHtml(student.previous_school)}</td>
        <td><div class="row-actions">${actions}</div></td>
    </tr>`;
}

function renderStudentTables() {
    const rows = state.students.map(student => studentRow(student)).join('');
    const removeRows = state.students.map(student => studentRow(student, true)).join('');
    document.getElementById('student-rows').innerHTML = rows || '<tr><td colspan="5" class="empty-state">No matching students found.</td></tr>';
    document.getElementById('remove-rows').innerHTML = removeRows || '<tr><td colspan="5" class="empty-state">No matching students found.</td></tr>';
    document.getElementById('student-result-count').textContent = `${state.students.length} student${state.students.length === 1 ? '' : 's'}`;
}

function updatePrintOptions() {
    const select = document.getElementById('print-student');
    const previous = select.value;
    select.innerHTML = '<option value="">Choose a student</option>' + state.students.map(student =>
        `<option value="${student.id}">${escapeHtml(student.admission_number)} · ${escapeHtml(fullName(student))}</option>`
    ).join('');
    if (state.students.some(student => String(student.id) === previous)) select.value = previous;
}

function navigateTo(panelName) {
    document.querySelectorAll('[data-panel]').forEach(panel => { panel.hidden = panel.id !== `panel-${panelName}`; });
    document.querySelectorAll('.side-nav button').forEach(button => button.classList.toggle('active', button.dataset.target === panelName));
    const titles = { dashboard: 'Dashboard', register: 'Register student', students: 'Student register', remove: 'Remove student', documents: 'Print documents' };
    document.getElementById('page-title').textContent = titles[panelName] || 'Administration';
    document.getElementById('sidebar').classList.remove('open');
    if (panelName === 'register') resetStudentForm();
    if (panelName === 'students' || panelName === 'remove') loadStudents().catch(error => showNotice(error.message, true));
}

function resetStudentForm() {
    const form = document.getElementById('student-form');
    form.reset();
    document.getElementById('student-id').value = '';
    document.getElementById('register-heading').textContent = 'Student profile';
    document.getElementById('submit-student').textContent = 'Register student';
    document.getElementById('cancel-edit').hidden = true;
}

async function editStudent(id) {
    const { student } = await api('student', { query: `&id=${encodeURIComponent(id)}` });
    navigateTo('register');
    document.getElementById('register-heading').textContent = 'Edit student details';
    document.getElementById('submit-student').textContent = 'Save changes';
    document.getElementById('cancel-edit').hidden = false;
    document.getElementById('student-id').value = student.id;
    fieldNames.forEach(name => {
        const field = document.getElementById(name);
        if (field) field.value = student[name] ?? '';
    });
    document.getElementById('first_name').focus();
}

async function viewStudent(id) {
    const { student } = await api('student', { query: `&id=${encodeURIComponent(id)}` });
    const fields = [
        ['Admission number', student.admission_number], ['Full name', fullName(student)], ['Gender', student.gender],
        ['Date of birth', student.date_of_birth || 'Not provided'], ['Guardian', student.guardian_name],
        ['Guardian phone', student.guardian_phone], ['Previous school', student.previous_school],
        ['Year completed', student.year_completed], ['Certificate', student.certificate_name],
        ['Index number', student.index_number], ['Marks / grade', student.marks_or_grade], ['Class completed', student.class_completed]
    ];
    document.getElementById('view-title').textContent = fullName(student);
    document.getElementById('view-details').innerHTML = fields.map(([label, value]) =>
        `<div class="field"><label>${escapeHtml(label)}</label><div>${escapeHtml(value)}</div></div>`
    ).join('');
    document.getElementById('view-dialog').showModal();
}

function openRemoveDialog(id) {
    const student = state.students.find(record => String(record.id) === String(id));
    if (!student) return;
    document.getElementById('remove-student-id').value = student.id;
    document.getElementById('remove-student-name').textContent = `${fullName(student)} · ${student.admission_number}`;
    document.getElementById('remove-reason').value = '';
    document.getElementById('remove-dialog').showModal();
}

async function printStudent(id) {
    const { student } = await api('student', { query: `&id=${encodeURIComponent(id)}` });
    const details = [
        ['Full name', fullName(student)], ['Gender', student.gender], ['Date of birth', student.date_of_birth || 'Not provided'],
        ['Guardian name', student.guardian_name], ['Guardian phone', student.guardian_phone],
        ['Previous school', student.previous_school], ['Year completed', student.year_completed],
        ['Certificate / examination', student.certificate_name], ['Index number', student.index_number],
        ['Marks / grade', student.marks_or_grade], ['Class completed', student.class_completed]
    ];
    document.getElementById('print-document').innerHTML = `
        <header class="print-school-head"><div class="print-logo">NSS</div><div>
            <h1>Nyabikongori Senior School</h1><p>Nyabikongori, Migori County, Kenya</p>
            <p>P.O.Box 160 - 40413, Kehancha · +254 721 413 332</p>
        </div></header>
        <h2 class="print-title">Student admission record</h2>
        <div class="print-date">Printed: ${escapeHtml(new Date().toLocaleDateString())}</div>
        <div class="print-admission">${escapeHtml(student.admission_number)}</div>
        <div class="print-details">${details.map(([label, value]) => `<div class="print-item"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}</div>
        <div class="print-signatures"><div>Parent / Guardian signature</div><div>Principal / Admissions officer</div></div>`;
    window.print();
}

document.getElementById('login-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = document.getElementById('login-submit');
    button.disabled = true;
    try {
        const result = await api('login', { method: 'POST', data: {
            email: document.getElementById('login-username').value.trim(),
            password: document.getElementById('login-password').value
        } });
        state.csrfToken = result.csrf_token;
        await enterDashboard();
        document.getElementById('login-password').value = '';
    } catch (error) {
        showNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('student-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    const id = data.id;
    delete data.id;
    const button = document.getElementById('submit-student');
    button.disabled = true;
    try {
        const result = await api(id ? 'update_student' : 'register_student', {
            method: 'POST', data: id ? { ...data, id } : data
        });
        if (id) {
            showNotice(result.message);
            resetStudentForm();
        } else {
            showNotice(`Student registered successfully. Admission number: ${result.admission_number}`);
            resetStudentForm();
            if (window.confirm(`Student registered with admission number ${result.admission_number}. Do you want to print the student's documents?`)) {
                await printStudent(result.student_id);
            }
        }
        await refreshSummary();
        await loadStudents();
        navigateTo('dashboard');
    } catch (error) {
        showNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('remove-form').addEventListener('submit', async event => {
    event.preventDefault();
    const id = document.getElementById('remove-student-id').value;
    const reason = document.getElementById('remove-reason').value;
    if (!window.confirm('Confirm this student removal? The record will be archived and removed from current totals.')) return;
    try {
        const result = await api('remove_student', { method: 'POST', data: { id, reason } });
        document.getElementById('remove-dialog').close();
        showNotice(result.message);
        await refreshSummary();
        await loadStudents();
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelectorAll('.side-nav button').forEach(button => button.addEventListener('click', () => navigateTo(button.dataset.target)));
document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => navigateTo(button.dataset.go)));
document.getElementById('cancel-edit').addEventListener('click', resetStudentForm);
document.getElementById('student-search').addEventListener('input', () => {
    window.clearTimeout(loadStudents.timer);
    loadStudents.timer = window.setTimeout(() => loadStudents().catch(error => showNotice(error.message, true)), 220);
});
document.getElementById('gender-filter').addEventListener('change', () => loadStudents().catch(error => showNotice(error.message, true)));
document.getElementById('remove-search').addEventListener('input', event => {
    document.getElementById('student-search').value = event.currentTarget.value;
    window.clearTimeout(loadStudents.timer);
    loadStudents.timer = window.setTimeout(() => loadStudents().catch(error => showNotice(error.message, true)), 220);
});
document.getElementById('student-rows').addEventListener('click', handleStudentAction);
document.getElementById('remove-rows').addEventListener('click', handleStudentAction);
document.getElementById('recent-rows').addEventListener('click', handleStudentAction);

async function handleStudentAction(event) {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const { action, id } = button.dataset;
    try {
        if (action === 'view') await viewStudent(id);
        if (action === 'edit') await editStudent(id);
        if (action === 'remove') openRemoveDialog(id);
    } catch (error) {
        showNotice(error.message, true);
    }
}

document.getElementById('print-selected').addEventListener('click', async () => {
    const id = document.getElementById('print-student').value;
    if (!id) return showNotice('Choose a student before printing.', true);
    try { await printStudent(id); } catch (error) { showNotice(error.message, true); }
});
document.getElementById('mobile-menu').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));
document.getElementById('logout-button').addEventListener('click', async () => {
    try {
        await api('logout', { method: 'POST', data: {} });
    } catch (error) {
        showNotice(error.message, true);
        return;
    }
    state.csrfToken = '';
    showLogin();
});
document.getElementById('close-view').addEventListener('click', () => document.getElementById('view-dialog').close());
document.getElementById('close-remove').addEventListener('click', () => document.getElementById('remove-dialog').close());

document.getElementById('top-date').textContent = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date());
api('admission_dashboard').then(summary => {
    state.csrfToken = summary.csrf_token || '';
    enterDashboard(summary).catch(showLogin);
}).catch(showLogin);
