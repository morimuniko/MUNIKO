const state = { csrfToken: null, admin: null, categories: [] };
const totalBooks = document.querySelector('#total-books');
const categoryList = document.querySelector('#category-list');
const bookRows = document.querySelector('#book-rows');
const searchInput = document.querySelector('#inventory-search');
const resultCount = document.querySelector('#result-count');
const notice = document.querySelector('#inventory-notice');
const loginForm = document.querySelector('#login-form');
const adminControls = document.querySelector('#admin-controls');
let inventoryRows = [];

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
    })[character]);
}

function renderCategories(categories) {
    state.categories = categories;
    categoryList.innerHTML = categories.length ? categories.map((category) =>
        `<article class="category-item"><span>${escapeHtml(category.name)}</span><strong>${Number(category.book_count) || 0}</strong></article>`
    ).join('') : '<p class="empty-state">No categories have been added yet.</p>';
    const categorySelect = document.querySelector('#book-category');
    categorySelect.innerHTML = categories.length
        ? categories.map((category) => `<option value="${Number(category.id)}">${escapeHtml(category.name)}</option>`).join('')
        : '<option value="">Add a category first</option>';
}

function renderBooks() {
    const query = searchInput.value.trim().toLocaleLowerCase();
    const filteredBooks = inventoryRows.filter((book) =>
        `${book.serial_number} ${book.title} ${book.author || ''} ${book.category}`.toLocaleLowerCase().includes(query)
    );

    bookRows.innerHTML = filteredBooks.length ? filteredBooks.map((book) => `
        <tr>
            <td>${escapeHtml(book.serial_number)}</td>
            <td><span class="book-title">${escapeHtml(book.title)}</span><span class="book-author">${escapeHtml(book.author || 'Author not recorded')}</span></td>
            <td>${escapeHtml(book.category)}</td>
        </tr>`).join('') : '<tr><td class="empty-state" colspan="3">No books match this search.</td></tr>';
    resultCount.textContent = `Showing ${filteredBooks.length} of ${inventoryRows.length} books`;
}

async function request(action, { method = 'GET', data } = {}) {
    return window.schoolSupabase.api(action, { method, data });
}

function updateAdmin(admin) {
    state.admin = admin;
    loginForm.hidden = Boolean(admin);
    adminControls.hidden = !admin;
    const status = document.querySelector('#admin-state');
    status.textContent = admin ? `Signed in: ${admin}` : 'Signed out';
    status.classList.toggle('signed-in', Boolean(admin));
}

async function loadInventory() {
    try {
        const data = await request('dashboard');

        totalBooks.textContent = Number(data.total_books) || 0;
        state.csrfToken = data.csrf_token || state.csrfToken;
        updateAdmin(data.admin || null);
        renderCategories(data.categories || []);
        inventoryRows = [...(data.books || [])].sort((first, second) =>
            first.category.localeCompare(second.category) || first.serial_number.localeCompare(second.serial_number, 'en', { numeric: true })
        );
        renderBooks();
    } catch (error) {
        notice.textContent = `${error.message} Check the Supabase connection, schema, and Auth role.`;
        notice.classList.add('visible', 'error');
        totalBooks.textContent = '—';
        categoryList.innerHTML = '<p class="empty-state">Category totals are unavailable.</p>';
        bookRows.innerHTML = '<tr><td class="empty-state" colspan="3">The inventory is unavailable.</td></tr>';
        resultCount.textContent = '';
    }
}

searchInput.addEventListener('input', renderBooks);

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
        const result = await request('login', {
            method: 'POST',
            data: Object.fromEntries(new FormData(loginForm).entries()),
        });
        state.csrfToken = result.csrf_token;
        await loadInventory();
        showInventoryNotice(`Signed in as ${result.admin}.`);
    } catch (error) {
        showInventoryNotice(error.message, true);
    }
});

document.querySelector('#logout-button').addEventListener('click', async () => {
    try {
        await request('logout', { method: 'POST', data: {} });
        state.csrfToken = null;
        updateAdmin(null);
        showInventoryNotice('Signed out.');
        await loadInventory();
    } catch (error) {
        showInventoryNotice(error.message, true);
    }
});

function showInventoryNotice(message, isError = false) {
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.classList.add('visible');
}

async function submitInventoryForm(form, action, successMessage) {
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const data = Object.fromEntries(new FormData(form).entries());
        if (action === 'book') data.category_id = Number(data.category_id);
        const result = await request(action, { method: 'POST', data });
        form.reset();
        await loadInventory();
        showInventoryNotice(result.message || successMessage);
    } catch (error) {
        showInventoryNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
}

document.querySelector('#category-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitInventoryForm(event.currentTarget, 'category', 'Category added and totals updated.');
});

document.querySelector('#book-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitInventoryForm(event.currentTarget, 'book', 'Book added and totals updated.');
});

loadInventory();