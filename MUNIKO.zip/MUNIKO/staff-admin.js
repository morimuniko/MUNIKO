const staffAdminState = { csrfToken: '', staff: [], admin: '' };

async function staffAdminApi(action, { method = 'GET', data, query = '' } = {}) {
    const result = await window.schoolSupabase.api(action, { method, data, query });
    if (result.csrf_token) staffAdminState.csrfToken = result.csrf_token;
    return result;
}

function staffAdminEscape(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function staffAdminNotice(message, isError = false) {
    const notice = document.getElementById('staff-admin-notice');
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.hidden = false;
    window.clearTimeout(staffAdminNotice.timeout);
    staffAdminNotice.timeout = window.setTimeout(() => { notice.hidden = true; }, 6000);
}

function showStaffLogin() {
    document.getElementById('staff-admin-login').hidden = false;
    document.getElementById('staff-admin-workspace').hidden = true;
    document.getElementById('admin-username').focus();
}

function showStaffEditor(adminName) {
    staffAdminState.admin = adminName;
    document.getElementById('signed-in-name').textContent = `Signed in as ${adminName}`;
    document.getElementById('staff-admin-login').hidden = true;
    document.getElementById('staff-admin-workspace').hidden = false;
}

function syncStaffTypeFields() {
    const isTeaching = document.getElementById('staff-type').value === 'teaching';
    const teachingFields = document.getElementById('teaching-fields');
    const nonTeachingFields = document.getElementById('non-teaching-fields');
    teachingFields.hidden = !isTeaching;
    nonTeachingFields.hidden = isTeaching;
    document.getElementById('leadership-position').required = isTeaching;
    document.getElementById('subjects').required = isTeaching;
    document.getElementById('work-type').required = !isTeaching;
    document.getElementById('leadership-title').required = isTeaching && document.getElementById('leadership-position').value === 'Staff Leader';
}

function resetStaffForm() {
    const form = document.getElementById('school-staff-form');
    form.reset();
    document.getElementById('school-staff-id').value = '';
    document.getElementById('staff-form-title').textContent = 'Add staff member';
    document.getElementById('save-staff').textContent = 'Save staff member';
    document.getElementById('current-photo-wrap').hidden = true;
    document.getElementById('current-staff-photo').removeAttribute('src');
    syncStaffTypeFields();
}

function staffDescription(member) {
    if (member.staff_type === 'teaching') {
        return `${member.leadership_position || 'Member'}${member.leadership_title ? ` · ${member.leadership_title}` : ''} · ${member.subjects || ''}`;
    }
    return member.work_type || 'Non-teaching staff';
}

function renderStaffList() {
    const filter = document.getElementById('staff-type-filter').value;
    const search = document.getElementById('staff-search').value.trim().toLocaleLowerCase();
    const visibleStaff = staffAdminState.staff.filter(member => {
        const matchesType = !filter || member.staff_type === filter;
        const haystack = [member.full_name, member.subjects, member.work_type, member.leadership_title, member.leadership_position].join(' ').toLocaleLowerCase();
        return matchesType && (!search || haystack.includes(search));
    });
    document.getElementById('staff-record-count').textContent = `${visibleStaff.length} record${visibleStaff.length === 1 ? '' : 's'}`;
    document.getElementById('admin-staff-list').innerHTML = visibleStaff.length ? visibleStaff.map(member => {
        const initials = member.full_name.trim().split(/\s+/).map(part => part[0]).slice(0, 2).join('').toUpperCase();
        const photo = member.photo_path
            ? `<img src="${staffAdminEscape(member.photo_path)}" alt="">`
            : `<div class="admin-staff-avatar" aria-hidden="true">${staffAdminEscape(initials)}</div>`;
        return `<article class="admin-staff-row">${photo}<div><h3>${staffAdminEscape(member.full_name)}</h3><p>${staffAdminEscape(member.staff_type === 'teaching' ? 'Teaching staff' : 'Non-teaching staff')} · ${staffAdminEscape(staffDescription(member))}</p></div><div class="admin-staff-actions"><button type="button" data-edit-staff="${member.id}">Edit</button><button class="delete-staff" type="button" data-delete-staff="${member.id}">Delete</button></div></article>`;
    }).join('') : '<p class="admin-list-empty">No matching staff records.</p>';
}

async function loadSchoolStaff() {
    const result = await staffAdminApi('school_staff_admin');
    staffAdminState.staff = result.staff;
    staffAdminState.admin = result.admin;
    staffAdminState.csrfToken = result.csrf_token || staffAdminState.csrfToken;
    showStaffEditor(result.admin);
    renderStaffList();
}

async function editStaffMember(id) {
    const result = await staffAdminApi('school_staff_member', { query: `&id=${encodeURIComponent(id)}` });
    const member = result.staff;
    resetStaffForm();
    document.getElementById('staff-form-title').textContent = 'Edit staff member';
    document.getElementById('save-staff').textContent = 'Save changes';
    document.getElementById('school-staff-id').value = member.id;
    document.getElementById('staff-type').value = member.staff_type;
    document.getElementById('staff-name').value = member.full_name;
    document.getElementById('leadership-position').value = member.leadership_position || 'Member';
    document.getElementById('leadership-title').value = member.leadership_title || '';
    document.getElementById('subjects').value = member.subjects || '';
    document.getElementById('work-type').value = member.work_type || '';
    syncStaffTypeFields();
    if (member.photo_path) {
        document.getElementById('current-staff-photo').src = member.photo_path;
        document.getElementById('current-photo-wrap').hidden = false;
    }
    document.getElementById('staff-name').focus();
}

async function deleteStaffMember(id) {
    const member = staffAdminState.staff.find(record => String(record.id) === String(id));
    if (!member || !window.confirm(`Remove ${member.full_name} from the school staff directory? This action cannot be undone.`)) return;
    try {
        const result = await staffAdminApi('delete_school_staff', { method: 'POST', data: { id } });
        if (document.getElementById('school-staff-id').value === String(id)) resetStaffForm();
        await loadSchoolStaff();
        staffAdminNotice(result.message);
    } catch (error) {
        staffAdminNotice(error.message, true);
    }
}

document.getElementById('staff-admin-login-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = event.currentTarget.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const result = await staffAdminApi('login', { method: 'POST', data: {
            email: document.getElementById('admin-username').value.trim(),
            password: document.getElementById('admin-password').value
        } });
        staffAdminState.csrfToken = result.csrf_token;
        document.getElementById('admin-password').value = '';
        await loadSchoolStaff();
    } catch (error) {
        staffAdminNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('school-staff-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const button = document.getElementById('save-staff');
    button.disabled = true;
    try {
        const result = await staffAdminApi('save_school_staff', { method: 'POST', data: new FormData(form) });
        resetStaffForm();
        await loadSchoolStaff();
        staffAdminNotice(result.message);
    } catch (error) {
        staffAdminNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('staff-type').addEventListener('change', syncStaffTypeFields);
document.getElementById('leadership-position').addEventListener('change', syncStaffTypeFields);
document.getElementById('new-staff').addEventListener('click', resetStaffForm);
document.getElementById('staff-type-filter').addEventListener('change', renderStaffList);
document.getElementById('staff-search').addEventListener('input', renderStaffList);
document.getElementById('admin-staff-list').addEventListener('click', event => {
    const editButton = event.target.closest('[data-edit-staff]');
    const deleteButton = event.target.closest('[data-delete-staff]');
    if (editButton) editStaffMember(editButton.dataset.editStaff).catch(error => staffAdminNotice(error.message, true));
    if (deleteButton) deleteStaffMember(deleteButton.dataset.deleteStaff);
});
document.getElementById('admin-logout').addEventListener('click', async () => {
    try {
        await staffAdminApi('logout', { method: 'POST', data: {} });
        staffAdminState.csrfToken = '';
        showStaffLogin();
    } catch (error) {
        staffAdminNotice(error.message, true);
    }
});

syncStaffTypeFields();
loadSchoolStaff().catch(showStaffLogin);
