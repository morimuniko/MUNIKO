<?php
declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$normalizedPath = str_replace('\\', '/', rawurldecode($path));

if (preg_match('~(?:^|/)(?:\.env|\.htaccess|\.git)(?:/|$)~i', $normalizedPath)) {
    http_response_code(404);
    exit('Not found');
}

$projectRoot = realpath(__DIR__);
$filePath = realpath(__DIR__ . $normalizedPath);
if ($normalizedPath !== '/' && $filePath && $projectRoot
    && str_starts_with($filePath, $projectRoot . DIRECTORY_SEPARATOR) && is_file($filePath)) {
    if (strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) === 'php') {
        require $filePath;
        exit;
    }
    return false;
}

$index = __DIR__ . '/index.html';
if (is_file($index)) {
    readfile($index);
    exit;
}
http_response_code(404);
echo 'Not found';
