create or replace function public.get_fee_payment_summary()
returns table(payment_count bigint, amount_total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
    if not (public.has_role('accounts_clerk') or public.has_role('admin')) then
        raise exception 'Accounts clerk access required';
    end if;
    return query select count(*)::bigint, coalesce(sum(amount_paid), 0)::numeric
    from public.fee_payments;
end;
$$;

create or replace function public.get_admission_summary()
returns table(total_students bigint, male_students bigint, female_students bigint)
language plpgsql stable security definer set search_path = public as $$
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    return query select count(*)::bigint,
        count(*) filter (where gender = 'Male')::bigint,
        count(*) filter (where gender = 'Female')::bigint
    from public.students;
end;
$$;

create or replace function public.search_fee_payments(p_search text default '')
returns setof public.fee_payments
language plpgsql stable security definer set search_path = public as $$
begin
    if not (public.has_role('accounts_clerk') or public.has_role('admin')) then
        raise exception 'Accounts clerk access required';
    end if;
    return query
    select payment.* from public.fee_payments payment
    where coalesce(trim(p_search), '') = ''
       or payment.admission_number ilike '%' || trim(p_search) || '%'
       or payment.student_name ilike '%' || trim(p_search) || '%'
       or payment.receipt_number ilike '%' || trim(p_search) || '%'
    order by payment.paid_at desc, payment.id desc
    limit 500;
end;
$$;

revoke all on function public.get_fee_payment_summary() from public;
revoke all on function public.get_admission_summary() from public;
revoke all on function public.search_fee_payments(text) from public;
grant execute on function public.get_fee_payment_summary() to authenticated;
grant execute on function public.get_admission_summary() to authenticated;
grant execute on function public.search_fee_payments(text) to authenticated;
