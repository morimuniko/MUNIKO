create extension if not exists pgcrypto;

create table if not exists public.user_roles (
    user_id uuid not null references auth.users(id) on delete cascade,
    role text not null check (role in ('admin', 'accounts_clerk')),
    created_at timestamptz not null default now(),
    primary key (user_id, role)
);

create or replace function public.has_role(required_role text)
returns boolean language sql stable security definer set search_path = public as $$
    select exists (
        select 1 from public.user_roles
        where user_id = (select auth.uid()) and role = required_role
    );
$$;
revoke all on function public.has_role(text) from public;
grant execute on function public.has_role(text) to anon, authenticated;

create table if not exists public.school_staff (
    id uuid primary key default gen_random_uuid(),
    staff_type text not null check (staff_type in ('teaching', 'non_teaching')),
    full_name text not null check (length(trim(full_name)) between 1 and 140),
    photo_path text,
    leadership_position text check (leadership_position in ('Staff Leader', 'Member')),
    leadership_title text,
    subjects text,
    work_type text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    check (
        (staff_type = 'teaching' and leadership_position is not null
            and length(trim(coalesce(subjects, ''))) > 0
            and (leadership_position <> 'Staff Leader' or length(trim(coalesce(leadership_title, ''))) > 0)
            and work_type is null)
        or
        (staff_type = 'non_teaching' and length(trim(coalesce(work_type, ''))) > 0
            and leadership_position is null and subjects is null)
    )
);
create unique index if not exists school_staff_type_name_unique
    on public.school_staff (staff_type, lower(trim(full_name)));

create table if not exists public.students (
    id uuid primary key default gen_random_uuid(),
    admission_number text not null unique,
    first_name text not null check (length(trim(first_name)) > 0),
    middle_name text not null default '',
    last_name text not null check (length(trim(last_name)) > 0),
    gender text not null check (gender in ('Male', 'Female')),
    date_of_birth date,
    guardian_name text not null check (length(trim(guardian_name)) > 0),
    guardian_phone text not null check (length(trim(guardian_phone)) > 0),
    previous_school text not null check (length(trim(previous_school)) > 0),
    year_completed smallint not null check (year_completed between 1900 and 2200),
    certificate_name text not null check (length(trim(certificate_name)) > 0),
    index_number text not null check (length(trim(index_number)) > 0),
    marks_or_grade text not null check (length(trim(marks_or_grade)) > 0),
    class_completed text not null check (length(trim(class_completed)) > 0),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create table if not exists public.removed_students (
    id uuid primary key default gen_random_uuid(),
    student_id uuid not null,
    admission_number text not null unique,
    first_name text not null,
    middle_name text not null default '',
    last_name text not null,
    gender text not null,
    date_of_birth date,
    guardian_name text not null,
    guardian_phone text not null,
    previous_school text not null,
    year_completed smallint not null,
    certificate_name text not null,
    index_number text not null,
    marks_or_grade text not null,
    class_completed text not null,
    reason text not null check (reason in ('Dropped out', 'Completed school')),
    removed_at timestamptz not null default now()
);
create table if not exists public.admission_sequences (
    admission_year smallint primary key,
    last_value bigint not null default 0 check (last_value >= 0)
);

create table if not exists public.accounts_clerk (
    user_id uuid primary key references auth.users(id) on delete cascade,
    full_name text not null check (length(trim(full_name)) between 1 and 140),
    username text not null unique check (length(trim(username)) > 0),
    email text not null check (position('@' in email) > 1),
    phone text not null check (phone ~ '^[+]?[0-9][0-9[:space:]().-]{6,23}$'),
    details text not null check (length(trim(details)) > 0),
    photo_path text not null check (length(trim(photo_path)) > 0),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create unique index if not exists accounts_clerk_single_profile on public.accounts_clerk ((true));
create table if not exists public.fee_payment_sequences (
    payment_year smallint primary key,
    last_value bigint not null default 0 check (last_value >= 0)
);
create table if not exists public.fee_payments (
    id uuid primary key default gen_random_uuid(),
    receipt_number text not null unique,
    student_name text not null check (length(trim(student_name)) > 0),
    admission_number text not null check (length(trim(admission_number)) > 0),
    form_grade text not null check (length(trim(form_grade)) > 0),
    amount_paid numeric(12, 2) not null check (amount_paid > 0),
    payment_method text not null default 'Cash' check (payment_method in ('Cash', 'M-Pesa', 'Bank', 'Cheque')),
    payment_reference text not null default '',
    paid_at timestamptz not null default now(),
    clerk_user_id uuid not null references auth.users(id),
    clerk_name text not null
);
create index if not exists fee_payments_admission_idx on public.fee_payments (admission_number);
create index if not exists fee_payments_paid_at_idx on public.fee_payments (paid_at desc);

create table if not exists public.library_categories (
    id bigint generated always as identity primary key,
    name text not null unique check (length(trim(name)) between 1 and 80),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create table if not exists public.books (
    id bigint generated always as identity primary key,
    serial_number text not null unique check (length(trim(serial_number)) > 0),
    title text not null check (length(trim(title)) > 0),
    author text not null default '',
    category_id bigint not null references public.library_categories(id) on update cascade on delete restrict,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create table if not exists public.loans (
    id bigint generated always as identity primary key,
    book_id bigint not null references public.books(id) on update cascade on delete restrict,
    borrower_name text not null check (length(trim(borrower_name)) > 0),
    borrower_class text not null default '',
    borrowed_at timestamptz not null default now(),
    returned_at timestamptz
);
create index if not exists loans_book_status_idx on public.loans (book_id, returned_at);
create index if not exists loans_borrowed_at_idx on public.loans (borrowed_at desc);
create table if not exists public.library_staff_profiles (
    id bigint generated always as identity primary key,
    role text not null unique check (role in ('head', 'council_leader')),
    full_name text not null,
    title text not null default '',
    phone text not null default '',
    email text,
    date_appointed date,
    details text not null default '',
    photo_path text,
    updated_at timestamptz not null default now()
);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

create or replace function public.accounts_clerk_exists()
returns boolean language sql stable security definer set search_path = public as $$
    select exists (select 1 from public.accounts_clerk);
$$;
revoke all on function public.accounts_clerk_exists() from public;
grant execute on function public.accounts_clerk_exists() to anon, authenticated;

create or replace function public.check_book_status(p_serial_number text)
returns table(serial_number text, title text, available boolean)
language sql stable security definer set search_path = public as $$
    select b.serial_number, b.title,
        not exists (select 1 from public.loans l where l.book_id = b.id and l.returned_at is null)
    from public.books b where b.serial_number = p_serial_number;
$$;
create or replace function public.list_public_books()
returns table(id bigint, serial_number text, title text, author text, category text, available boolean, created_at timestamptz)
language sql stable security definer set search_path = public as $$
    select b.id, b.serial_number, b.title, b.author, c.name,
        not exists (select 1 from public.loans l where l.book_id = b.id and l.returned_at is null), b.created_at
    from public.books b join public.library_categories c on c.id = b.category_id;
$$;
create or replace function public.list_public_loans()
returns table(id bigint, serial_number text, title text, borrowed_at timestamptz, returned_at timestamptz)
language sql stable security definer set search_path = public as $$
    select l.id, b.serial_number, b.title, l.borrowed_at, l.returned_at
    from public.loans l join public.books b on b.id = l.book_id order by l.borrowed_at desc;
$$;

create or replace function public.register_student(
    p_first_name text, p_middle_name text, p_last_name text, p_gender text, p_date_of_birth date,
    p_guardian_name text, p_guardian_phone text, p_previous_school text, p_year_completed smallint,
    p_certificate_name text, p_index_number text, p_marks_or_grade text, p_class_completed text
)
returns setof public.students language plpgsql security definer set search_path = public as $$
declare
    current_year smallint := extract(year from now())::smallint;
    next_number bigint;
    generated_admission text;
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    if length(trim(coalesce(p_first_name, ''))) = 0 or length(trim(coalesce(p_last_name, ''))) = 0
       or length(trim(coalesce(p_guardian_name, ''))) = 0 or length(trim(coalesce(p_guardian_phone, ''))) = 0
       or length(trim(coalesce(p_previous_school, ''))) = 0 or length(trim(coalesce(p_certificate_name, ''))) = 0
       or length(trim(coalesce(p_index_number, ''))) = 0 or length(trim(coalesce(p_marks_or_grade, ''))) = 0
       or length(trim(coalesce(p_class_completed, ''))) = 0 then
        raise exception 'All required student and academic details must be supplied';
    end if;
    if p_year_completed < 1900 or p_year_completed > current_year then raise exception 'Enter a valid year completed'; end if;
    if p_gender not in ('Male', 'Female') then raise exception 'Choose Male or Female'; end if;
    insert into public.admission_sequences (admission_year, last_value) values (current_year, 1)
    on conflict (admission_year) do update set last_value = public.admission_sequences.last_value + 1
    returning last_value into next_number;
    generated_admission := 'ADM/' || current_year::text || '/' || lpad(next_number::text, 3, '0');
    return query insert into public.students (
        admission_number, first_name, middle_name, last_name, gender, date_of_birth, guardian_name,
        guardian_phone, previous_school, year_completed, certificate_name, index_number, marks_or_grade, class_completed
    ) values (
        generated_admission, trim(p_first_name), coalesce(trim(p_middle_name), ''), trim(p_last_name), p_gender,
        p_date_of_birth, trim(p_guardian_name), trim(p_guardian_phone), trim(p_previous_school), p_year_completed,
        trim(p_certificate_name), trim(p_index_number), trim(p_marks_or_grade), trim(p_class_completed)
    ) returning *;
end;
$$;

create or replace function public.archive_student(p_student_id uuid, p_reason text)
returns boolean language plpgsql security definer set search_path = public as $$
declare archived_count integer;
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    if p_reason not in ('Dropped out', 'Completed school') then raise exception 'Invalid removal reason'; end if;
    with removed as (delete from public.students where id = p_student_id returning *)
    insert into public.removed_students (
        student_id, admission_number, first_name, middle_name, last_name, gender, date_of_birth, guardian_name,
        guardian_phone, previous_school, year_completed, certificate_name, index_number, marks_or_grade, class_completed, reason
    ) select id, admission_number, first_name, middle_name, last_name, gender, date_of_birth, guardian_name,
        guardian_phone, previous_school, year_completed, certificate_name, index_number, marks_or_grade, class_completed, p_reason from removed;
    get diagnostics archived_count = row_count;
    if archived_count = 0 then raise exception 'Student not found'; end if;
    return true;
end;
$$;

create or replace function public.record_fee_payment(
    p_student_name text, p_admission_number text, p_form_grade text, p_amount_paid numeric,
    p_payment_method text default 'Cash', p_payment_reference text default ''
)
returns setof public.fee_payments language plpgsql security definer set search_path = public as $$
declare
    current_year smallint := extract(year from now())::smallint;
    next_number bigint;
    generated_receipt text;
    clerk_name text;
begin
    if not (public.has_role('accounts_clerk') or public.has_role('admin')) then raise exception 'Accounts clerk access required'; end if;
    if length(trim(coalesce(p_student_name, ''))) = 0 or length(trim(coalesce(p_admission_number, ''))) = 0
       or length(trim(coalesce(p_form_grade, ''))) = 0 or p_amount_paid is null or p_amount_paid <= 0 then
        raise exception 'Student name, admission number, form/grade and a positive amount are required';
    end if;
    select full_name into clerk_name from public.accounts_clerk where user_id = auth.uid();
    if clerk_name is null and public.has_role('admin') then clerk_name := coalesce(auth.jwt() -> 'user_metadata' ->> 'full_name', auth.jwt() ->> 'email', 'Administrator'); end if;
    if clerk_name is null then raise exception 'Complete the accounts clerk profile before recording payments'; end if;
    insert into public.fee_payment_sequences (payment_year, last_value) values (current_year, 1)
    on conflict (payment_year) do update set last_value = public.fee_payment_sequences.last_value + 1
    returning last_value into next_number;
    generated_receipt := 'NSS-FEE/' || current_year::text || '/' || lpad(next_number::text, 6, '0');
    return query insert into public.fee_payments (
        receipt_number, student_name, admission_number, form_grade, amount_paid, payment_method,
        payment_reference, clerk_user_id, clerk_name
    ) values (
        generated_receipt, trim(p_student_name), trim(p_admission_number), trim(p_form_grade), p_amount_paid,
        coalesce(p_payment_method, 'Cash'), coalesce(trim(p_payment_reference), ''), auth.uid(), clerk_name
    ) returning *;
end;
$$;

create or replace function public.record_book_loan(p_book_id bigint, p_borrower_name text, p_borrower_class text default '')
returns setof public.loans language plpgsql security definer set search_path = public as $$
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    perform id from public.books where id = p_book_id for update;
    if not found then raise exception 'Book not found'; end if;
    if exists(select 1 from public.loans where book_id = p_book_id and returned_at is null) then raise exception 'This book is already borrowed'; end if;
    return query insert into public.loans (book_id, borrower_name, borrower_class)
        values (p_book_id, trim(p_borrower_name), coalesce(trim(p_borrower_class), '')) returning *;
end;
$$;
create or replace function public.record_book_return(p_loan_id bigint)
returns boolean language plpgsql security definer set search_path = public as $$
declare changed_rows integer;
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    update public.loans set returned_at = now() where id = p_loan_id and returned_at is null;
    get diagnostics changed_rows = row_count;
    if changed_rows = 0 then raise exception 'Loan was already returned or does not exist'; end if;
    return true;
end;
$$;

alter table public.user_roles enable row level security;
drop policy if exists "Users read own roles" on public.user_roles;
create policy "Users read own roles" on public.user_roles for select to authenticated using (user_id = (select auth.uid()));
alter table public.school_staff enable row level security;
drop policy if exists "Public read school staff" on public.school_staff;
create policy "Public read school staff" on public.school_staff for select to anon, authenticated using (true);
drop policy if exists "Admins manage school staff" on public.school_staff;
create policy "Admins manage school staff" on public.school_staff for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));

alter table public.students enable row level security;
drop policy if exists "Admins read students" on public.students;
create policy "Admins read students" on public.students for select to authenticated using (public.has_role('admin'));
drop policy if exists "Admins update students" on public.students;
create policy "Admins update students" on public.students for update to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
alter table public.removed_students enable row level security;
drop policy if exists "Admins read removed students" on public.removed_students;
create policy "Admins read removed students" on public.removed_students for select to authenticated using (public.has_role('admin'));
alter table public.admission_sequences enable row level security;
drop policy if exists "Admins read admission sequences" on public.admission_sequences;
create policy "Admins read admission sequences" on public.admission_sequences for select to authenticated using (public.has_role('admin'));

alter table public.accounts_clerk enable row level security;
drop policy if exists "Clerks and admins read clerk profile" on public.accounts_clerk;
create policy "Clerks and admins read clerk profile" on public.accounts_clerk for select to authenticated using (user_id = (select auth.uid()) or public.has_role('admin'));
drop policy if exists "Clerks and admins insert clerk profile" on public.accounts_clerk;
create policy "Clerks and admins insert clerk profile" on public.accounts_clerk for insert to authenticated with check ((user_id = (select auth.uid()) and public.has_role('accounts_clerk')) or public.has_role('admin'));
drop policy if exists "Clerks and admins update clerk profile" on public.accounts_clerk;
create policy "Clerks and admins update clerk profile" on public.accounts_clerk for update to authenticated using ((user_id = (select auth.uid()) and public.has_role('accounts_clerk')) or public.has_role('admin')) with check ((user_id = (select auth.uid()) and public.has_role('accounts_clerk')) or public.has_role('admin'));

alter table public.fee_payments enable row level security;
drop policy if exists "Clerks and admins read fee payments" on public.fee_payments;
create policy "Clerks and admins read fee payments" on public.fee_payments for select to authenticated using (public.has_role('accounts_clerk') or public.has_role('admin'));
alter table public.fee_payment_sequences enable row level security;

alter table public.library_categories enable row level security;
drop policy if exists "Public read categories" on public.library_categories;
create policy "Public read categories" on public.library_categories for select to anon, authenticated using (true);
drop policy if exists "Admins manage categories" on public.library_categories;
create policy "Admins manage categories" on public.library_categories for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
alter table public.books enable row level security;
drop policy if exists "Admins manage books" on public.books;
create policy "Admins manage books" on public.books for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
alter table public.loans enable row level security;
drop policy if exists "Admins manage loans" on public.loans;
create policy "Admins manage loans" on public.loans for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
alter table public.library_staff_profiles enable row level security;
drop policy if exists "Public read library staff" on public.library_staff_profiles;
create policy "Public read library staff" on public.library_staff_profiles for select to anon, authenticated using (true);
drop policy if exists "Admins manage library staff" on public.library_staff_profiles;
create policy "Admins manage library staff" on public.library_staff_profiles for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));

revoke all on function public.register_student(text,text,text,text,date,text,text,text,smallint,text,text,text,text) from public;
revoke all on function public.archive_student(uuid,text) from public;
revoke all on function public.record_fee_payment(text,text,text,numeric,text,text) from public;
revoke all on function public.record_book_loan(bigint,text,text) from public;
revoke all on function public.record_book_return(bigint) from public;
revoke all on function public.check_book_status(text) from public;
revoke all on function public.list_public_books() from public;
revoke all on function public.list_public_loans() from public;
revoke all on function public.accounts_clerk_exists() from public;
grant execute on function public.register_student(text,text,text,text,date,text,text,text,smallint,text,text,text,text) to authenticated;
grant execute on function public.archive_student(uuid,text) to authenticated;
grant execute on function public.record_fee_payment(text,text,text,numeric,text,text) to authenticated;
grant execute on function public.record_book_loan(bigint,text,text) to authenticated;
grant execute on function public.record_book_return(bigint) to authenticated;
grant execute on function public.check_book_status(text) to anon, authenticated;
grant execute on function public.list_public_books() to anon, authenticated;
grant execute on function public.list_public_loans() to anon, authenticated;
grant execute on function public.accounts_clerk_exists() to anon, authenticated;

grant usage on schema public to anon, authenticated;
grant select on public.school_staff, public.library_categories, public.library_staff_profiles to anon, authenticated;
grant select, insert, update, delete on public.school_staff to authenticated;
grant select, update on public.students to authenticated;
grant select on public.removed_students, public.user_roles, public.fee_payments to authenticated;
grant select, insert, update on public.accounts_clerk to authenticated;
grant insert, update, delete on public.library_categories to authenticated;
grant select, insert, update, delete on public.books to authenticated;
grant select, insert, update on public.loans to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profile-photos', 'profile-photos', true, 3145728, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;
drop policy if exists "Public can view profile photos" on storage.objects;
drop policy if exists "Admins manage profile photos" on storage.objects;
create policy "Admins manage profile photos" on storage.objects for all to authenticated using (bucket_id = 'profile-photos' and public.has_role('admin')) with check (bucket_id = 'profile-photos' and public.has_role('admin'));
drop policy if exists "Clerks manage own profile photos" on storage.objects;
create policy "Clerks manage own profile photos" on storage.objects for all to authenticated using (bucket_id = 'profile-photos' and public.has_role('accounts_clerk') and (storage.foldername(name))[1] = (select auth.uid())::text) with check (bucket_id = 'profile-photos' and public.has_role('accounts_clerk') and (storage.foldername(name))[1] = (select auth.uid())::text);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists school_staff_touch_updated_at on public.school_staff;
create trigger school_staff_touch_updated_at before update on public.school_staff for each row execute function public.touch_updated_at();
drop trigger if exists students_touch_updated_at on public.students;
create trigger students_touch_updated_at before update on public.students for each row execute function public.touch_updated_at();
drop trigger if exists accounts_clerk_touch_updated_at on public.accounts_clerk;
create trigger accounts_clerk_touch_updated_at before update on public.accounts_clerk for each row execute function public.touch_updated_at();
drop trigger if exists categories_touch_updated_at on public.library_categories;
create trigger categories_touch_updated_at before update on public.library_categories for each row execute function public.touch_updated_at();
drop trigger if exists books_touch_updated_at on public.books;
create trigger books_touch_updated_at before update on public.books for each row execute function public.touch_updated_at();
drop trigger if exists library_staff_touch_updated_at on public.library_staff_profiles;
create trigger library_staff_touch_updated_at before update on public.library_staff_profiles for each row execute function public.touch_updated_at();

insert into public.library_categories (name) values ('Science'), ('Computer Science'), ('Fiction'), ('Reference') on conflict (name) do nothing;
