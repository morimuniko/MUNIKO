# Supabase setup

Run `schema.sql`, then `functions-and-grants.sql`, then `dashboard-functions.sql` in the Supabase SQL Editor. These create the application tables, RLS policies, transactional RPCs, dashboard summaries, and the `profile-photos` Storage bucket.

The browser SDK is loaded from jsDelivr ESM in `supabaseClient.js`, so no Node build step or package installation is required. It fetches the project URL and public anon key from `config/supabase-config.php`, which reads `config/.env` on the PHP server. Paste the anon/public key only into `config/.env`; never put a service-role/secret key there or in browser code.

Create admin and accounts-clerk users in Supabase Authentication. Disable public signups. Then insert their Auth UUID and `admin` or `accounts_clerk` role into `public.user_roles` using the SQL in `docs/supabase-setup.md`. Users must have the correct role before role-protected access is available.

The previous MySQL `backend/schema.sql` is retained only as a migration reference. The pages no longer call `backend/api.php`; `backend/api.php` has been retired.
