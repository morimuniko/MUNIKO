create or replace function public.check_book_status(p_serial_number text)
returns table(serial_number text, title text, available boolean)
language sql stable security definer set search_path = public as $$
    select b.serial_number, b.title,
        not exists (select 1 from public.loans l where l.book_id = b.id and l.returned_at is null)
    from public.books b where b.serial_number = p_serial_number;
$$;

create or replace function public.list_public_books()
returns table(id bigint, serial_number text, title text, author text, category text, available boolean, created_at timestamptz)
language sql stable security definer set search_path = public as $$
    select b.id, b.serial_number, b.title, b.author, c.name,
        not exists (select 1 from public.loans l where l.book_id = b.id and l.returned_at is null), b.created_at
    from public.books b join public.library_categories c on c.id = b.category_id;
$$;

create or replace function public.list_public_loans()
returns table(id bigint, serial_number text, title text, borrowed_at timestamptz, returned_at timestamptz)
language sql stable security definer set search_path = public as $$
    select l.id, b.serial_number, b.title, l.borrowed_at, l.returned_at
    from public.loans l join public.books b on b.id = l.book_id
    order by l.borrowed_at desc;
$$;

create or replace function public.record_book_loan(p_book_id bigint, p_borrower_name text, p_borrower_class text default '')
returns setof public.loans language plpgsql security definer set search_path = public as $$
declare
    book_exists boolean;
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    select exists(select 1 from public.books where id = p_book_id) into book_exists;
    if not book_exists then raise exception 'Book not found'; end if;
    perform id from public.books where id = p_book_id for update;
    if exists(select 1 from public.loans where book_id = p_book_id and returned_at is null) then
        raise exception 'This book is already borrowed';
    end if;
    return query insert into public.loans (book_id, borrower_name, borrower_class)
        values (p_book_id, trim(p_borrower_name), coalesce(trim(p_borrower_class), '')) returning *;
end;
$$;

create or replace function public.record_book_return(p_loan_id bigint)
returns boolean language plpgsql security definer set search_path = public as $$
declare
    changed_rows integer;
begin
    if not public.has_role('admin') then raise exception 'Administrator access required'; end if;
    update public.loans set returned_at = now() where id = p_loan_id and returned_at is null;
    get diagnostics changed_rows = row_count;
    if changed_rows = 0 then raise exception 'Loan was already returned or does not exist'; end if;
    return true;
end;
$$;

revoke all on function public.check_book_status(text) from public;
revoke all on function public.list_public_books() from public;
revoke all on function public.list_public_loans() from public;
revoke all on function public.record_book_loan(bigint,text,text) from public;
revoke all on function public.record_book_return(bigint) from public;
grant execute on function public.check_book_status(text) to anon, authenticated;
grant execute on function public.list_public_books() to anon, authenticated;
grant execute on function public.list_public_loans() to anon, authenticated;
grant execute on function public.record_book_loan(bigint,text,text) to authenticated;
grant execute on function public.record_book_return(bigint) to authenticated;

revoke all on public.user_roles, public.school_staff, public.students, public.removed_students,
    public.admission_sequences, public.accounts_clerk, public.fee_payment_sequences, public.fee_payments,
    public.library_categories, public.books, public.loans, public.library_staff_profiles
from anon, authenticated;
grant usage on schema public to anon, authenticated;
grant select on public.school_staff to anon, authenticated;
grant select, insert, update, delete on public.school_staff to authenticated;
grant select, update on public.students to authenticated;
grant select on public.removed_students to authenticated;
grant select, insert, update on public.accounts_clerk to authenticated;
grant select on public.fee_payments to authenticated;
grant select on public.library_categories to anon, authenticated;
grant insert, update, delete on public.library_categories to authenticated;
grant select, insert, update, delete on public.books to authenticated;
grant select, insert, update on public.loans to authenticated;
grant select on public.library_staff_profiles to anon, authenticated;
grant insert, update, delete on public.library_staff_profiles to authenticated;
grant select on public.user_roles to authenticated;

drop trigger if exists school_staff_touch_updated_at on public.school_staff;
create trigger school_staff_touch_updated_at before update on public.school_staff for each row execute function public.touch_updated_at();
drop trigger if exists students_touch_updated_at on public.students;
create trigger students_touch_updated_at before update on public.students for each row execute function public.touch_updated_at();
drop trigger if exists accounts_clerk_touch_updated_at on public.accounts_clerk;
create trigger accounts_clerk_touch_updated_at before update on public.accounts_clerk for each row execute function public.touch_updated_at();
drop trigger if exists categories_touch_updated_at on public.library_categories;
create trigger categories_touch_updated_at before update on public.library_categories for each row execute function public.touch_updated_at();
drop trigger if exists books_touch_updated_at on public.books;
create trigger books_touch_updated_at before update on public.books for each row execute function public.touch_updated_at();
drop trigger if exists library_staff_touch_updated_at on public.library_staff_profiles;
create trigger library_staff_touch_updated_at before update on public.library_staff_profiles for each row execute function public.touch_updated_at();
