const accountState = { csrfToken: '', clerk: null, payments: [] };

async function accountsApi(action, { method = 'GET', data, query = '' } = {}) {
    return window.schoolSupabase.api(action, { method, data, query });
}

function html(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function currency(value) {
    return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES' }).format(Number(value || 0));
}

function readableDate(value, includeTime = false) {
    if (!value) return '';
    const parsed = new Date(String(value).replace(' ', 'T'));
    if (Number.isNaN(parsed.getTime())) return String(value);
    return new Intl.DateTimeFormat(undefined, includeTime
        ? { dateStyle: 'medium', timeStyle: 'short' }
        : { dateStyle: 'medium' }).format(parsed);
}

function notice(message, isError = false) {
    const element = document.getElementById('notice');
    element.textContent = message;
    element.classList.toggle('error', isError);
    element.hidden = false;
    window.clearTimeout(notice.timeout);
    notice.timeout = window.setTimeout(() => { element.hidden = true; }, 6500);
}

function showAuth(mode) {
    document.getElementById('auth-screen').hidden = false;
    document.getElementById('office-app').hidden = true;
    document.getElementById('clerk-setup-form').hidden = mode !== 'setup';
    document.getElementById('clerk-login-form').hidden = mode !== 'login';
    if (mode === 'setup') document.getElementById('setup-full-name').focus();
    if (mode === 'login') document.getElementById('clerk-username').focus();
}

function showOffice() {
    document.getElementById('auth-screen').hidden = true;
    document.getElementById('office-app').hidden = false;
}

function populateClerk(clerk) {
    accountState.clerk = clerk;
    document.getElementById('sidebar-clerk-name').textContent = clerk.full_name;
    document.getElementById('dashboard-name').textContent = clerk.full_name;
    document.getElementById('dashboard-details').textContent = clerk.details;
    document.getElementById('dashboard-email').textContent = clerk.email;
    document.getElementById('dashboard-email').href = `mailto:${clerk.email}`;
    document.getElementById('dashboard-phone').textContent = clerk.phone;
    document.getElementById('dashboard-phone').href = `tel:${clerk.phone.replace(/[^+\d]/g, '')}`;
    const photo = document.getElementById('dashboard-photo');
    photo.src = clerk.photo_path || '';
    photo.alt = `${clerk.full_name} profile photo`;
    document.getElementById('profile-full-name').value = clerk.full_name;
    document.getElementById('profile-email').value = clerk.email;
    document.getElementById('profile-phone').value = clerk.phone;
    document.getElementById('profile-details').value = clerk.details;
    document.getElementById('profile-username').value = clerk.username;
    document.getElementById('profile-password').value = '';
    document.getElementById('profile-password-confirmation').value = '';
}

async function loadDashboard() {
    const result = await accountsApi('accounts_dashboard');
    accountState.csrfToken = result.csrf_token || accountState.csrfToken;
    if (!result.clerk) {
        if (result.can_setup) {
            showAuth('setup');
            return result;
        }
        throw new Error('This account is not assigned the accounts_clerk role.');
    }
    populateClerk(result.clerk);
    document.getElementById('payment-count').textContent = result.payment_count;
    document.getElementById('amount-total').textContent = currency(result.amount_total);
    const rows = result.recent_payments.map(payment => `<tr>
        <td class="receipt-code">${html(payment.receipt_number)}</td>
        <td><strong>${html(payment.student_name)}</strong></td>
        <td>${currency(payment.amount_paid)}</td>
        <td>${html(readableDate(payment.paid_at))}</td>
    </tr>`).join('');
    document.getElementById('recent-payment-rows').innerHTML = rows || '<tr><td class="empty-state" colspan="4">No fees have been recorded yet.</td></tr>';
    showOffice();
    return result;
}

function navigate(view) {
    document.querySelectorAll('[data-office-view]').forEach(section => { section.hidden = section.id !== `view-${view}`; });
    document.querySelectorAll('.side-nav button').forEach(button => button.classList.toggle('active', button.dataset.view === view));
    const titles = { dashboard: 'Accounts dashboard', payment: 'Record fee payment', records: 'Payment records', profile: 'Change clerk details' };
    document.getElementById('view-title').textContent = titles[view] || 'Accounts office';
    document.getElementById('office-sidebar').classList.remove('open');
    if (view === 'records') loadPayments().catch(error => notice(error.message, true));
    if (view === 'profile') document.getElementById('profile-full-name').focus();
    if (view === 'payment') document.getElementById('student-name').focus();
}

async function loadPayments() {
    const search = document.getElementById('payment-search').value.trim();
    const query = new URLSearchParams({ search }).toString();
    const result = await accountsApi('accounts_payments', { query: `&${query}` });
    accountState.payments = result.payments;
    renderPayments();
}

function renderPayments() {
    const rows = accountState.payments.map(payment => `<tr>
        <td class="receipt-code">${html(payment.receipt_number)}</td>
        <td><strong>${html(payment.student_name)}</strong></td>
        <td>${html(payment.admission_number)}</td>
        <td>${html(payment.form_grade)}</td>
        <td>${currency(payment.amount_paid)}</td>
        <td>${html(payment.payment_method)}</td>
        <td>${html(readableDate(payment.paid_at))}</td>
        <td><button class="row-button" type="button" data-print-receipt="${payment.id}">Receipt</button></td>
    </tr>`).join('');
    document.getElementById('payment-rows').innerHTML = rows || '<tr><td class="empty-state" colspan="8">No matching fee payment records.</td></tr>';
    document.getElementById('record-count').textContent = `${accountState.payments.length} payment record${accountState.payments.length === 1 ? '' : 's'}`;
}

function documentHeader(title) {
    return `<header class="print-header"><div class="print-crest">NSS</div><div><h1>Nyabikongori Senior School</h1><p>Nyabikongori, Migori County, Kenya</p><p>P.O.Box 160 - 40413, Kehancha · +254 721 413 332</p></div></header>
        <h2 class="print-title">${html(title)}</h2><p class="print-meta">Printed: ${html(new Date().toLocaleString())}</p>`;
}

function printDocument(markup) {
    document.getElementById('print-area').innerHTML = markup;
    document.body.classList.add('printing');
    window.print();
    window.setTimeout(() => document.body.classList.remove('printing'), 500);
}

function printReceipt(payment) {
    const rows = [
        ['Receipt number', payment.receipt_number],
        ['Student name', payment.student_name],
        ['Admission number', payment.admission_number],
        ['Form / grade', payment.form_grade],
        ['Payment method', payment.payment_method],
        ['Payment reference', payment.payment_reference || 'Not provided'],
        ['Received by', payment.clerk_name]
    ];
    printDocument(`${documentHeader('Official school fees receipt')}
        <div class="print-fields">${rows.map(([label, value]) => `<div class="print-field"><span>${html(label)}</span><strong>${html(value)}</strong></div>`).join('')}</div>
        <div class="receipt-total">Amount paid: ${html(currency(payment.amount_paid))}</div>
        <p class="print-meta">Payment date: ${html(readableDate(payment.paid_at, true))}</p>
        <div class="print-signature">Accounts clerk signature</div>`);
}

function printProfile() {
    if (!accountState.clerk) return;
    const clerk = accountState.clerk;
    const rows = [['Full name', clerk.full_name], ['Email address', clerk.email], ['Phone number', clerk.phone], ['Profile details', clerk.details], ['Login username', clerk.username]];
    printDocument(`${documentHeader('Accounts clerk profile')}
        <div class="print-fields">${rows.map(([label, value]) => `<div class="print-field"><span>${html(label)}</span><strong>${html(value)}</strong></div>`).join('')}</div>
        <div class="print-signature">School administration</div>`);
}

function printPaymentRegister() {
    const rows = accountState.payments.map(payment => `<tr><td>${html(payment.receipt_number)}</td><td>${html(payment.student_name)}</td><td>${html(payment.admission_number)}</td><td>${html(payment.form_grade)}</td><td>${html(currency(payment.amount_paid))}</td><td>${html(payment.payment_method)}</td><td>${html(readableDate(payment.paid_at))}</td></tr>`).join('');
    printDocument(`${documentHeader('School fees payment register')}
        <table><thead><tr><th>Receipt</th><th>Student</th><th>Admission</th><th>Form / grade</th><th>Amount</th><th>Method</th><th>Date</th></tr></thead><tbody>${rows || '<tr><td colspan="7">No matching records.</td></tr>'}</tbody></table>
        <div class="print-fields"><div class="print-field"><span>Records shown</span><strong>${accountState.payments.length}</strong></div><div class="print-field"><span>Total shown</span><strong>${html(currency(accountState.payments.reduce((sum, payment) => sum + Number(payment.amount_paid), 0)))}</strong></div></div>
        <div class="print-signature">Accounts clerk signature</div>`);
}

function refreshAccountsViews() {
    return Promise.all([loadDashboard(), loadPayments()]);
}

document.getElementById('clerk-setup-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = document.getElementById('setup-submit');
    button.disabled = true;
    try {
        const result = await accountsApi('register_clerk', { method: 'POST', data: new FormData(form) });
        form.reset();
        await loadDashboard();
        notice(result.message);
    } catch (error) {
        notice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('clerk-login-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = document.getElementById('login-submit');
    button.disabled = true;
    try {
        const result = await accountsApi('clerk_login', { method: 'POST', data: {
            email: document.getElementById('clerk-username').value.trim(),
            password: document.getElementById('clerk-password').value
        } });
        accountState.csrfToken = result.csrf_token;
        document.getElementById('clerk-password').value = '';
        await loadDashboard();
    } catch (error) {
        notice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('payment-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = Object.fromEntries(new FormData(form).entries());
    if (!data.student_name.trim() || !data.admission_number.trim() || !data.form_grade.trim() || Number(data.amount_paid) <= 0) {
        notice('Enter the student name, admission number, form/grade, and an amount greater than zero. No receipt was generated.', true);
        return;
    }
    const button = document.getElementById('record-payment');
    button.disabled = true;
    try {
        const result = await accountsApi('record_payment', { method: 'POST', data });
        form.reset();
        await Promise.all([loadDashboard(), loadPayments()]);
        if (window.confirm(`Payment saved. Receipt ${result.payment.receipt_number} generated. Do you want to print a hardcopy?`)) {
            printReceipt(result.payment);
        } else {
            notice(`Payment saved. Receipt ${result.payment.receipt_number} is available in Payment records.`);
        }
    } catch (error) {
        notice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.getElementById('clerk-profile-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const password = document.getElementById('profile-password').value;
    const confirmation = document.getElementById('profile-password-confirmation').value;
    if (password && password !== confirmation) return notice('The new passwords do not match.', true);
    const email = document.getElementById('profile-email').value.trim();
    const emailChanged = email !== accountState.clerk.email;
    if (password || emailChanged) {
        const client = await window.schoolSupabase.client();
        const changes = {};
        if (email !== accountState.clerk.email) changes.email = email;
        if (password) changes.password = password;
        const { error } = await client.auth.updateUser(changes);
        if (error) return notice(error.message, true);
    }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const result = await accountsApi('update_clerk', { method: 'POST', data: new FormData(form) });
        form.reset();
        await loadDashboard();
        notice(emailChanged ? 'Profile saved. Confirm the email change using the message Supabase sent to your new address.' : result.message);
    } catch (error) {
        notice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

document.querySelectorAll('.side-nav button').forEach(button => button.addEventListener('click', () => navigate(button.dataset.view)));
document.querySelectorAll('[data-open-view]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.openView)));
document.getElementById('payment-search').addEventListener('input', () => {
    window.clearTimeout(loadPayments.timer);
    loadPayments.timer = window.setTimeout(() => loadPayments().catch(error => notice(error.message, true)), 250);
});
document.getElementById('payment-rows').addEventListener('click', event => {
    const button = event.target.closest('[data-print-receipt]');
    if (!button) return;
    const payment = accountState.payments.find(record => String(record.id) === button.dataset.printReceipt);
    if (payment) printReceipt(payment);
});
document.getElementById('print-profile').addEventListener('click', printProfile);
document.getElementById('print-records').addEventListener('click', printPaymentRegister);
document.getElementById('menu-toggle').addEventListener('click', () => document.getElementById('office-sidebar').classList.toggle('open'));
document.getElementById('logout-button').addEventListener('click', async () => {
    try {
        await accountsApi('clerk_logout', { method: 'POST', data: {} });
        accountState.csrfToken = '';
        showAuth('login');
    } catch (error) {
        notice(error.message, true);
    }
});

document.getElementById('today-date').textContent = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date());
accountsApi('accounts_status').then(status => {
    accountsApi('accounts_dashboard').then(result => {
        accountState.csrfToken = result.csrf_token || '';
        if (!result.clerk) {
            if (result.can_setup) showAuth('setup');
            else {
                showAuth('login');
                notice('This account is not assigned the accounts_clerk role.');
            }
            return;
        }
        populateClerk(result.clerk);
        document.getElementById('payment-count').textContent = result.payment_count;
        document.getElementById('amount-total').textContent = currency(result.amount_total);
        const rows = result.recent_payments.map(payment => `<tr><td class="receipt-code">${html(payment.receipt_number)}</td><td><strong>${html(payment.student_name)}</strong></td><td>${currency(payment.amount_paid)}</td><td>${html(readableDate(payment.paid_at))}</td></tr>`).join('');
        document.getElementById('recent-payment-rows').innerHTML = rows || '<tr><td class="empty-state" colspan="4">No fees have been recorded yet.</td></tr>';
        showOffice();
    }).catch(() => showAuth('login'));
}).catch(() => {
    showAuth('login');
    notice('The accounts service is unavailable. Check the Supabase URL, anon key, schema, and Auth setup.', true);
});
