<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$configPath = __DIR__ . '/.env';
$config = is_file($configPath) ? parse_ini_file($configPath, false, INI_SCANNER_RAW) : false;
$url = is_array($config) ? trim((string) ($config['SUPABASE_URL'] ?? '')) : '';
$anonKey = is_array($config) ? trim((string) ($config['SUPABASE_ANON_KEY'] ?? '')) : '';

if (!filter_var($url, FILTER_VALIDATE_URL) || !str_ends_with((string) parse_url($url, PHP_URL_HOST), '.supabase.co')) {
    http_response_code(500);
    echo json_encode(['error' => 'Set a valid SUPABASE_URL in config/.env.']);
    exit;
}
if ($anonKey === '' || $anonKey === 'PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE') {
    http_response_code(503);
    echo json_encode(['error' => 'Paste your Supabase anon public key into config/.env.']);
    exit;
}

echo json_encode(['url' => $url, 'anon_key' => $anonKey], JSON_UNESCAPED_SLASHES);
