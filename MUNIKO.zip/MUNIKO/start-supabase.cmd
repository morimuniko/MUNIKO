@echo off
setlocal EnableExtensions
set "PROJECT_DIR=%~dp0"

set "PHP_EXE="
if defined XAMPP_HOME if exist "%XAMPP_HOME%\php\php.exe" set "PHP_EXE=%XAMPP_HOME%\php\php.exe"
if not defined PHP_EXE if exist "C:\xampp\php\php.exe" set "PHP_EXE=C:\xampp\php\php.exe"
if not defined PHP_EXE if exist "C:\Program Files\xampp\php\php.exe" set "PHP_EXE=C:\Program Files\xampp\php\php.exe"
if not defined PHP_EXE if exist "D:\xampp\php\php.exe" set "PHP_EXE=D:\xampp\php\php.exe"
if not defined PHP_EXE (
    echo XAMPP PHP was not found. Install XAMPP or set XAMPP_HOME to its folder first.
    pause
    exit /b 1
)

"%PHP_EXE%" -r "exit(version_compare(PHP_VERSION, '8.0.0', '>=') ? 0 : 1);"
if errorlevel 1 (
    echo PHP 8 or newer is required.
    pause
    exit /b 1
)

if not exist "%PROJECT_DIR%config\.env" (
    echo Missing config\.env. Paste your Supabase URL and anon public key into it first.
    pause
    exit /b 1
)

netstat -ano | findstr /R /C:":8000 .*LISTENING" >nul
if not errorlevel 1 (
    echo Port 8000 is already in use. Close the other server or change this launcher's port.
    pause
    exit /b 1
)

start "Nyabikongori Supabase Website" /D "%PROJECT_DIR%" "%PHP_EXE%" -S 127.0.0.1:8000 -t "%PROJECT_DIR%" "%PROJECT_DIR%router.php"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8000/"
echo Site opened at http://127.0.0.1:8000/
echo Keep the PHP server window open. Database, Auth, and Storage use Supabase.
echo.
pause
endlocal
