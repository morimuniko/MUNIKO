const SUPABASE_CONFIG_URL = 'config/supabase-config.php';

window.supabaseReady = (async () => {
    if (location.protocol === 'file:') {
        throw new Error('Open this site through Apache/PHP or start-supabase.cmd; file:// cannot read config/.env.');
    }
    const response = await fetch(SUPABASE_CONFIG_URL, { cache: 'no-store' });
    let config;
    try { config = await response.json(); }
    catch { throw new Error('The Supabase config endpoint did not return JSON. Check that PHP is running.'); }
    if (!response.ok) throw new Error(config.error || 'Supabase configuration could not be loaded.');
    const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    const client = createClient(config.url, config.anon_key, {
        auth: {
            autoRefreshToken: true,
            detectSessionInUrl: true,
            persistSession: true
        }
    });
    const { error } = await client.from('school_staff').select('id').limit(1);
    if (error) throw error;
    console.info('Connected to Supabase');
    return client;
})().catch(error => {
    console.error('Supabase connection failed:', error.message);
    document.dispatchEvent(new CustomEvent('supabase-config-error', { detail: error.message }));
    throw error;
});

document.addEventListener('supabase-config-error', event => {
    const notice = document.querySelector('#notice, #app-notice, #staff-admin-notice, #inventory-notice, #borrowing-notice');
    if (!notice) return;
    notice.textContent = `Supabase setup error: ${event.detail}. Check config/.env and run the Supabase SQL scripts.`;
    notice.hidden = false;
    notice.classList.add('visible', 'error');
});
