@echo off
setlocal
call "%~dp0start-supabase.cmd"
endlocal
