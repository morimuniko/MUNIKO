# Accounts Office User Guide

## One-time setup

Complete [Supabase setup](supabase-setup.md) first. Create a user under Supabase **Authentication > Users**, add the Auth user's UUID to `public.user_roles` with role `accounts_clerk`, and paste the anon/public key into `config/.env`. Start Apache and run `start-supabase.cmd`.

Open `accounts office.html` through the PHP server. Sign in with the clerk's Supabase Auth email/password. On first login, complete the profile form and upload a JPG/PNG/WEBP photo (maximum 3 MB). The app stores no clerk password; Supabase Auth manages credentials.

## Take payments and print

1. Open **Record fee payment**.
2. Enter student name, admission number, form/grade, and a positive amount. Payment method is required from the existing choices; reference is optional.
3. Submit. The database RPC validates fields and amount, increments the yearly receipt sequence, and saves the receipt atomically.
4. Confirm the print prompt to print, or open **Payment records** and search by name, admission number, or receipt number. Each saved row can be reprinted. **Print payment records** prints the filtered results; the dashboard can print the clerk profile.
5. Under **Change clerk details**, update profile information/photo. Credential changes use `supabase.auth.updateUser`; email changes may need confirmation from the new address.

Receipts include school name/address, receipt number, student and admission details, amount, method/reference, date, receiving clerk, and signature line. Amounts use KES.

## Database design

```mermaid
erDiagram
    AUTH_USERS ||--o| ACCOUNTS_CLERK : profile
    AUTH_USERS ||--o{ FEE_PAYMENTS : records
    AUTH_USERS {
        uuid id PK
        text email
    }
    ACCOUNTS_CLERK {
        uuid user_id PK, FK
        text full_name
        text username
        text email
        text phone
        text details
        text photo_path
        timestamptz created_at
        timestamptz updated_at
    }
    FEE_PAYMENTS {
        uuid id PK
        text receipt_number UK
        text student_name
        text admission_number
        text form_grade
        numeric amount_paid
        text payment_method
        text payment_reference
        timestamptz paid_at
        uuid clerk_user_id FK
        text clerk_name
    }
```

The `fee_payment_sequences` table keeps the yearly counter. `record_fee_payment()` checks the clerk/admin role and all receipt-required values inside PostgreSQL before inserting a row. Amount must be greater than zero.

## Access and storage

RLS allows only the accounts-clerk or admin roles to read payment records. Inserts occur through the role-checked payment RPC. A clerk can read/edit their own profile; admins can read/manage the profile. Photos are stored in the public `profile-photos` bucket for display; upload/delete policies require an admin or the clerk's own Auth UUID folder. No service-role key is used in the browser.

## Test checklist

| Test | Expected result |
| --- | --- |
| Jane Wanjiku / 2451 / Form 3 / 15,000 | One saved row and unique receipt; print prompt appears. |
| Missing student, admission, or grade | Validation error; no payment row or receipt. |
| Amount is zero or negative | Validation error; no payment row or receipt. |
| Search by admission number/receipt | Matching saved payments appear and can be reprinted. |
| Update clerk profile/photo | Profile persists after reload; image uses Storage URL. |
| Unauthenticated or wrong-role data access | Supabase RLS denies payment/profile operations. |
| Print receipt/profile/payment list | School heading/date and intended detail/table remain in print layout. |

Browser-only form checks were previously performed; persistence, Auth, RLS, Storage, and actual print output must be verified after you configure the Supabase project. Existing screenshots under `screenshots/` predate this Auth change and show UI layouts only; capture new sign-in/setup/receipt screens after configuration.
