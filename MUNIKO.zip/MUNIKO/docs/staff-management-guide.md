# Staff Management User Guide

## One-time setup

Follow [Supabase setup](supabase-setup.md): run `supabase/schema.sql`, `supabase/functions-and-grants.sql`, and `supabase/dashboard-functions.sql` in that order; paste your anon/public key in `config/.env`; create a Supabase Auth user; and assign that user's `admin` role in `public.user_roles`. Start Apache and run `start-supabase.cmd`. Admin passwords are managed by Supabase Auth and never stored in `school_staff`.

## Manage staff

1. Open `staff-admin.html` and sign in with the admin email/password created in Supabase Auth.
2. Choose **Teaching staff** or **Non-teaching staff**, and enter the full name.
3. For teaching staff, choose **Staff Leader** or **Member**, enter subjects, and provide the specific title for a Staff Leader. For non-teaching staff, enter the work type.
4. Optionally upload a JPG, PNG, or WEBP picture up to 3 MB. Save the record. Duplicate names within one category are rejected by a unique database index.
5. Search/filter the directory. **Edit** updates an existing row; omitting a replacement photo retains its Storage path. **Delete** asks for confirmation and then removes the row/photo.
6. Public pages and home lists read from Supabase after refresh. Select **Print staff list** on a public category page to confirm and open a print-friendly school heading, date, and staff table.

## Database design

```mermaid
erDiagram
    AUTH_USERS ||--o{ USER_ROLES : assigned
    SCHOOL_STAFF {
        uuid id PK
        text staff_type
        text full_name
        text photo_path
        text leadership_position
        text leadership_title
        text subjects
        text work_type
        timestamptz created_at
        timestamptz updated_at
    }
    AUTH_USERS {
        uuid id PK
        text email
    }
    USER_ROLES {
        uuid user_id PK, FK
        text role PK
        timestamptz created_at
    }
```

`school_staff` has a UUID primary key and a unique index on `(staff_type, lower(trim(full_name)))`. Type-specific fields are checked in PostgreSQL. Profile images are stored in the `profile-photos` bucket; `photo_path` contains the object path, not the image bytes.

## Access rules

Anyone can read teaching/non-teaching staff. Only an authenticated user with the `admin` role can insert, edit, or delete. The anon key alone cannot change records. `user_roles` is only readable by the signed-in user; role assignment is done by the Supabase project owner through SQL Editor.

## Acceptance checks

| Check | Expected result |
| --- | --- |
| Public teaching/non-teaching page | Shows only the selected category, with photo or initials placeholder. |
| Add a teacher or non-teaching employee | Valid record saves and appears in the correct list/home preview. |
| Leave a required/type-specific field blank | Browser or database validation prevents saving. |
| Duplicate same-category name | Database unique index rejects it. |
| Upload unsupported or oversized photo | Client and Storage policy reject the image. |
| Edit and omit photo | Details update; old image path remains. |
| Delete and cancel | No change; confirming deletion removes the record. |
| Unauthenticated/wrong-role write | Supabase RLS denies the operation. |
| Print list | Cancel does not print; Yes prints school name/date/staff table. |

The browser was checked for mobile menu overflow, both staff dropdowns, and print confirmation/layout. Database/Auth/Storage behavior must be tested after configuring your own key and running the SQL scripts.

## Screenshots

The screenshots in [`screenshots`](screenshots/) include the home page, teaching and non-teaching directories, admin login, editor, and print layout. Public/editor/print captures use illustrative browser-only rows; they are not live database evidence. Re-capture after connecting your Supabase project to document real persisted data.
