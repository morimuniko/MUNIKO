# Supabase Setup and User Guide

This site is plain HTML/CSS/JavaScript served by PHP. Supabase provides the database, Auth, and Storage; PHP is used only to read the local config file safely. You do not need Node.js or npm.

## 1. Add the anon key

Open `config/.env`. The Supabase project URL is already filled in. Paste the project's **anon / publishable public key** after `SUPABASE_ANON_KEY=`:

```env
SUPABASE_URL=https://mngxbcmpevahffezvojj.supabase.co
SUPABASE_ANON_KEY=PASTE_THE_ANON_PUBLIC_KEY_HERE
```

Get the key from **Supabase Dashboard > Project Settings > API**. Never paste a `service_role` or secret key into any project file. The anon key is intentionally public; RLS is what protects data. `config/.env` is git-ignored and blocked from HTTP access; `config/supabase-config.php` returns only the URL and anon key to the browser.

## 2. Create the database

1. Open **Supabase Dashboard > SQL Editor** for project `mngxbcmpevahffezvojj`.
2. Run `supabase/schema.sql`.
3. Run `supabase/functions-and-grants.sql`.
4. Run `supabase/dashboard-functions.sql`.

The first file creates the tables, RLS policies, photo bucket, and core RPCs. The second grants only the necessary table and function operations and adds timestamps. The third creates exact dashboard summary RPCs.

## 3. Create Auth accounts and roles

The site does not offer public admin/clerk account signup. Create accounts in **Authentication > Users > Add user** and set a strong password. Turn off public signups in **Authentication > Settings**. Copy each Auth user's UUID, then run the matching role insert in SQL Editor:

```sql
insert into public.user_roles (user_id, role)
values ('PASTE_ADMIN_AUTH_UUID_HERE', 'admin');

insert into public.user_roles (user_id, role)
values ('PASTE_CLERK_AUTH_UUID_HERE', 'accounts_clerk');
```

Assign a user both roles only if that person needs both admin and accounts-clerk permissions. Passwords are managed by Supabase Auth, not stored in app tables. The accounts clerk signs in first and completes the clerk profile and photo on first use.

## 4. Run locally

Install XAMPP with PHP 8+, put the project in `htdocs/MUNIKO`, start Apache, then run `start-supabase.cmd` (or the compatibility wrapper `start-library.cmd`). Open `http://127.0.0.1:8000/`. Do not use `file:///`; the PHP config endpoint is required. The browser console should log **Connected to Supabase**.

The SDK is loaded from the Supabase v2 ESM CDN. An internet connection is needed in the browser. No service-role key or Supabase password is shipped in JavaScript.

## 5. What is stored

| Table | Data and access |
| --- | --- |
| `user_roles` | Auth UUID and `admin`/`accounts_clerk` role. Users may read only their own role. Role changes are made by the project owner in SQL Editor. |
| `school_staff` | Teaching/non-teaching people, leadership/subject or work type, photo path, timestamps. Public read; admin writes. |
| `students` | Student and prior-school records. Admin read/update; registration uses an atomic RPC. |
| `removed_students` | Archived student snapshot, reason, removal timestamp. Admin read; atomic archive RPC writes it. |
| `admission_sequences` | Per-year atomic admission number counter. Admin read; registration RPC updates it. |
| `accounts_clerk` | One active clerk's profile and public photo path, linked to an Auth UUID. Clerk/admin read and write. No password column. |
| `fee_payments` | Receipt, student, amount, method/reference, date, and clerk snapshot. Clerk/admin read; a validated RPC writes receipts. |
| `fee_payment_sequences` | Atomic yearly receipt counter. Modified only inside the payment RPC. |
| `library_categories`, `books` | Catalog and categories. Categories are public read; books are returned through a limited public RPC. Admin writes. |
| `loans` | Library borrowing records. Admin reads/writes. The public history RPC returns title/serial/dates only, never borrower names/classes. |
| `library_staff_profiles` | Library leadership profiles. Public read; admin writes. |

All tables have RLS enabled. Browser requests use only the anon key; `user_roles` determines access and RLS rechecks every protected query/write. Summary/sequence/receipt RPCs use fixed `search_path`, check role, and keep increments plus inserts atomic.

## 6. Profile photo Storage

`supabase/schema.sql` creates the public `profile-photos` bucket with a 3 MB limit and JPG/PNG/WEBP MIME types. Photos are publicly readable for public profiles, but uploads/deletes require an admin or a clerk writing only within their Auth-UUID folder. The tables store the Storage object path; the site turns it into a public display URL.

## 7. Test checklist

- Load the home page through PHP and check the browser console for **Connected to Supabase**.
- Visit the teaching and non-teaching pages; add/edit/delete a profile as admin and confirm public lists update after refresh.
- Try a duplicate name in one category and an invalid image; both should show an error.
- Sign in to admissions, register a student, verify its `ADM/YYYY/NNN` number, edit it, archive it, and verify the totals/history.
- Sign in as clerk, complete profile/photo, record a positive fee payment, search by admission/receipt, and print receipt/profile/payment list. Empty required values and amount `0` must not create a payment/receipt.
- Add a library category/book, check public availability, record borrow/return as admin. The public status/history must never show who borrowed a book.
- Sign out and retry write actions or use a wrong-role account; RLS must reject them.

## 8. Existing MySQL data

The SQL creates Supabase tables but does not move data from the old MySQL database. Export each needed MySQL table to CSV, import matching columns through **Table Editor > Import data from CSV**, and verify records before switching fully. Upload old photo files to `profile-photos`, then change `photo_path` to each new Storage object path. Do not import old password hashes; create new Supabase Auth users and assign roles as above. Keep a MySQL backup until all row counts, images, and printouts have been checked.

If importing existing admissions or fee receipts, initialize `admission_sequences` and `fee_payment_sequences` to the highest existing number for each year before allowing new registrations/payments; otherwise generated numbers may collide with imported data. Do not reset those counters after launch.

Do not use the old `backend/schema.sql` as the live Supabase schema; it is the legacy MySQL layout retained only as a migration reference.
