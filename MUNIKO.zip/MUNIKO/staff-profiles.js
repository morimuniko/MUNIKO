const state = { staff: [], csrfToken: null };
const notice = document.querySelector('#app-notice');
const staffList = document.querySelector('#staff-list');
const loginForm = document.querySelector('#login-form');
const staffForm = document.querySelector('#staff-form');

const roles = [
    { key: 'head', label: 'Head of Library' },
    { key: 'council_leader', label: 'School Executive Council leader' },
];

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
    })[character]);
}

function showNotice(message, isError = false) {
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.classList.add('visible');
}

async function request(action, { method = 'GET', data, formData = false } = {}) {
    return window.schoolSupabase.api(action, { method, data: formData ? data : data });
}

function formatDate(value) {
    if (!value) return '';
    const date = new Date(`${value}T00:00:00`);
    return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('en-GB', {
        day: '2-digit', month: 'long', year: 'numeric',
    }).format(date);
}

function renderStaff() {
    staffList.innerHTML = roles.map(({ key, label }) => {
        const profile = state.staff.find((item) => item.role === key);
        const photo = profile?.photo_path
            ? `<img class="staff-photo" src="${escapeHtml(profile.photo_path)}" alt="Portrait of ${escapeHtml(profile.full_name)}">`
            : '<div class="staff-photo" aria-hidden="true">NS</div>';
        const title = profile?.title ? `<p>${escapeHtml(profile.title)}</p>` : '';
        const phone = profile?.phone ? `<p><a href="tel:${escapeHtml(profile.phone)}">${escapeHtml(profile.phone)}</a></p>` : '';
        const email = profile?.email ? `<p><a href="mailto:${escapeHtml(profile.email)}">${escapeHtml(profile.email)}</a></p>` : '';
        const appointed = profile?.date_appointed
            ? `<p>Appointed ${escapeHtml(formatDate(profile.date_appointed))}</p>` : '';
        const details = profile?.details ? `<p>${escapeHtml(profile.details)}</p>` : '';
        return `<article class="staff-profile">${photo}<div><p class="staff-role">${label}</p><h3>${escapeHtml(profile?.full_name || 'Profile not yet added')}</h3>${title}${phone}${email}${appointed}${details}</div></article>`;
    }).join('');
}

function updateAdminState(admin) {
    const signedIn = Boolean(admin);
    loginForm.hidden = signedIn;
    document.querySelector('#admin-controls').hidden = !signedIn;
    const status = document.querySelector('#admin-state');
    status.textContent = signedIn ? `Signed in: ${admin}` : 'Signed out';
    status.classList.toggle('signed-in', signedIn);
}

async function loadProfiles() {
    try {
        const client = await window.schoolSupabase.client();
        const { data: profiles, error } = await client.from('library_staff_profiles').select('*');
        if (error) throw error;
        state.staff = (profiles || []).map(profile => ({
            ...profile,
            photo_path: window.schoolSupabase.photoUrl(client, profile.photo_path)
        }));
        const user = await window.schoolSupabase.currentUser(client);
        const isAdmin = user && await window.schoolSupabase.hasRole(client, user.id, 'admin');
        renderStaff();
        updateAdminState(isAdmin ? user.email : null);
        loadSelectedProfile();
    } catch (error) {
        staffList.innerHTML = '<p class="empty-state">Staff profiles are unavailable. Check the Supabase connection and schema setup.</p>';
        showNotice(error.message, true);
    }
}

function loadSelectedProfile() {
    const profile = state.staff.find((item) => item.role === document.querySelector('#staff-role').value);
    for (const field of ['full_name', 'title', 'phone', 'email', 'date_appointed', 'details']) {
        staffForm.elements[field].value = profile?.[field] || '';
    }
    staffForm.elements.photo.value = '';
}

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
        const result = await request('login', {
            method: 'POST',
            data: Object.fromEntries(new FormData(loginForm).entries()),
        });
        await window.schoolSupabase.requireRole(await window.schoolSupabase.client(), 'admin');
        showNotice(`Signed in as ${result.admin}.`);
        await loadProfiles();
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#logout-button').addEventListener('click', async () => {
    try {
        await request('logout', { method: 'POST', data: {} });
        updateAdminState(null);
        showNotice('Signed out.');
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#staff-role').addEventListener('change', loadSelectedProfile);

staffForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = staffForm.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const result = await request('staff', {
            method: 'POST', data: new FormData(staffForm), formData: true,
        });
        showNotice(result.message || 'Staff profile saved.');
        await loadProfiles();
    } catch (error) {
        showNotice(error.message, true);
    } finally {
        button.disabled = false;
    }
});

loadProfiles();