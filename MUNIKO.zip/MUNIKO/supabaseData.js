window.schoolSupabase = {
    async client() { return window.supabaseReady; },
    async result(promise) {
        const { data, error } = await promise;
        if (error) throw error;
        return data;
    },
    async currentUser(client) {
        const { data: { user }, error } = await client.auth.getUser();
        if (error) throw error;
        return user;
    },
    async hasRole(client, userId, role) {
        const { data, error } = await client.from('user_roles').select('role').eq('user_id', userId).eq('role', role).maybeSingle();
        if (error) throw error;
        return Boolean(data);
    },
    async requireRole(client, role) {
        const user = await this.currentUser(client);
        if (!user) throw new Error('Please sign in to continue.');
        if (!await this.hasRole(client, user.id, role)) throw new Error('This account is not authorized for this page.');
        return user;
    },
    async uploadPhoto(client, userId, file, folder = 'staff') {
        if (!file || !file.size) return null;
        const types = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
        if (!types[file.type] || file.size > 3 * 1024 * 1024) throw new Error('Choose a JPG, PNG, or WEBP image no larger than 3 MB.');
        let decodedImage;
        try { decodedImage = await createImageBitmap(file); }
        catch { throw new Error('The selected file is not a readable image.'); }
        decodedImage.close();
        const path = `${userId}/${folder}/${crypto.randomUUID()}.${types[file.type]}`;
        const { error } = await client.storage.from('profile-photos').upload(path, file, { cacheControl: '3600', contentType: file.type, upsert: false });
        if (error) throw error;
        return path;
    },
    photoUrl(client, path) {
        if (!path) return '';
        if (/^https?:\/\//i.test(path)) return path;
        return client.storage.from('profile-photos').getPublicUrl(path).data.publicUrl;
    },
    async deletePhoto(client, path) {
        if (!path || /^https?:\/\//i.test(path)) return;
        const { error } = await client.storage.from('profile-photos').remove([path]);
        if (error) console.warn('Could not remove old profile photo:', error.message);
    },
    async signIn(client, email, password) {
        const { data, error } = await client.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        return data.user;
    },
    async signOut(client) {
        const { error } = await client.auth.signOut();
        if (error) throw error;
    },
    async api(rawAction, { method = 'GET', data, query = '', formData = false } = {}) {
        const client = await this.client();
        const [action, inlineQuery = ''] = rawAction.split('&', 2);
        const params = new URLSearchParams(`${inlineQuery}${query.replace(/^&/, '&')}`);
        const user = await this.currentUser(client);
        const requireAdmin = async () => this.requireRole(client, 'admin');
        const requireClerk = async () => this.requireRole(client, 'accounts_clerk');
        const profilePhoto = (record) => record ? { ...record, photo_path: this.photoUrl(client, record.photo_path) } : record;
        const normalizedDate = (value) => value || null;

        if (action === 'login') {
            const loggedIn = await this.signIn(client, data.email || data.username, data.password || '');
            try { await this.requireRole(client, 'admin'); }
            catch (error) { await this.signOut(client); throw error; }
            return { admin: loggedIn.email, user: loggedIn };
        }
        if (action === 'clerk_login') {
            const loggedIn = await this.signIn(client, data.email || data.username, data.password || '');
            try { await this.requireRole(client, 'accounts_clerk'); }
            catch (error) { await this.signOut(client); throw error; }
            return { clerk: loggedIn.email, user: loggedIn };
        }
        if (action === 'logout' || action === 'clerk_logout') {
            await this.signOut(client);
            return { message: 'Signed out.' };
        }
        if (action === 'school_staff') {
            const type = params.get('type');
            let request = client.from('school_staff').select('*').order('full_name');
            if (type) request = request.eq('staff_type', type);
            const rows = await this.result(request);
            return { staff: rows.map(profilePhoto) };
        }
        if (action === 'school_staff_admin') {
            const admin = await requireAdmin();
            const rows = await this.result(client.from('school_staff').select('*').order('staff_type').order('full_name'));
            return { staff: rows.map(profilePhoto), admin: admin.email, csrf_token: 'supabase-auth' };
        }
        if (action === 'school_staff_member') {
            await requireAdmin();
            const row = await this.result(client.from('school_staff').select('*').eq('id', params.get('id')).single());
            return { staff: profilePhoto(row) };
        }
        if (action === 'save_school_staff') {
            const admin = await requireAdmin();
            const form = data;
            const id = form.get('id');
            const old = id ? await this.result(client.from('school_staff').select('*').eq('id', id).single()) : null;
            const image = await this.uploadPhoto(client, admin.id, form.get('photo'), 'staff');
            const record = {
                staff_type: form.get('staff_type'), full_name: form.get('full_name').trim(),
                leadership_position: form.get('staff_type') === 'teaching' ? form.get('leadership_position') : null,
                leadership_title: form.get('staff_type') === 'teaching' ? (form.get('leadership_title').trim() || null) : null,
                subjects: form.get('staff_type') === 'teaching' ? form.get('subjects').trim() : null,
                work_type: form.get('staff_type') === 'non_teaching' ? form.get('work_type').trim() : null,
                photo_path: image || old?.photo_path || null
            };
            try {
                if (id) await this.result(client.from('school_staff').update(record).eq('id', id).select().single());
                else await this.result(client.from('school_staff').insert(record).select().single());
            } catch (error) {
                if (image) await this.deletePhoto(client, image);
                if (error.code === '23505') throw new Error('A staff member with that name and staff type already exists.');
                throw error;
            }
            if (image && old?.photo_path) await this.deletePhoto(client, old.photo_path);
            return { message: id ? 'Staff member updated.' : 'Staff member added.' };
        }
        if (action === 'delete_school_staff') {
            await requireAdmin();
            const old = await this.result(client.from('school_staff').select('photo_path').eq('id', data.id).single());
            await this.result(client.from('school_staff').delete().eq('id', data.id));
            await this.deletePhoto(client, old.photo_path);
            return { message: 'Staff member removed.' };
        }
        if (action === 'accounts_status') {
            return { clerk_exists: await this.result(client.rpc('accounts_clerk_exists')) };
        }
        if (action === 'register_clerk') {
            const clerk = await requireClerk();
            const form = data;
            const photo = await this.uploadPhoto(client, clerk.id, form.get('photo'), 'clerk');
            const record = {
                user_id: clerk.id, full_name: form.get('full_name').trim(),
                username: clerk.email.split('@')[0], email: clerk.email,
                phone: form.get('phone').trim(), details: form.get('details').trim(), photo_path: photo
            };
            try { await this.result(client.from('accounts_clerk').insert(record).select().single()); }
            catch (error) { if (photo) await this.deletePhoto(client, photo); throw error; }
            return { message: 'Accounts clerk profile saved.' };
        }
        if (action === 'accounts_dashboard') {
            const clerk = user && await this.hasRole(client, user.id, 'accounts_clerk');
            if (!clerk) await requireAdmin();
            let profileQuery = client.from('accounts_clerk').select('*');
            if (clerk) profileQuery = profileQuery.eq('user_id', user.id);
            const profile = await this.result(profileQuery.maybeSingle());
            if (clerk && profile && profile.email !== user.email) {
                await this.result(client.from('accounts_clerk').update({ email: user.email }).eq('user_id', user.id));
                profile.email = user.email;
            }
            const [summaryRows, recent] = await Promise.all([
                this.result(client.rpc('get_fee_payment_summary')),
                this.result(client.from('fee_payments').select('*').order('paid_at', { ascending: false }).limit(8))
            ]);
            const summary = summaryRows[0] || { payment_count: 0, amount_total: 0 };
            const clerkRecord = profile ? { ...profile, email: user.email } : null;
            return {
                clerk: profilePhoto(clerkRecord), payment_count: Number(summary.payment_count),
                amount_total: Number(summary.amount_total),
                recent_payments: recent, can_setup: Boolean(clerk), csrf_token: 'supabase-auth'
            };
        }
        if (action === 'accounts_payments') {
            await requireClerk();
            const rows = await this.result(client.rpc('search_fee_payments', { p_search: params.get('search') || '' }));
            return { payments: rows };
        }
        if (action === 'record_payment') {
            await requireClerk();
            const payment = await this.result(client.rpc('record_fee_payment', {
                p_student_name: data.student_name, p_admission_number: data.admission_number,
                p_form_grade: data.form_grade, p_amount_paid: Number(data.amount_paid),
                p_payment_method: data.payment_method || 'Cash', p_payment_reference: data.payment_reference || ''
            }));
            return { message: 'Payment recorded and receipt generated.', payment: Array.isArray(payment) ? payment[0] : payment };
        }
        if (action === 'update_clerk') {
            const clerk = await requireClerk();
            const form = data;
            const old = await this.result(client.from('accounts_clerk').select('*').eq('user_id', clerk.id).single());
            const email = clerk.email;
            const image = await this.uploadPhoto(client, clerk.id, form.get('photo'), 'clerk');
            const record = {
                full_name: form.get('full_name').trim(), username: form.get('username').trim() || email.split('@')[0], email,
                phone: form.get('phone').trim(), details: form.get('details').trim(), photo_path: image || old.photo_path
            };
            try { await this.result(client.from('accounts_clerk').update(record).eq('user_id', clerk.id)); }
            catch (error) { if (image) await this.deletePhoto(client, image); throw error; }
            if (image && old.photo_path) await this.deletePhoto(client, old.photo_path);
            return { message: 'Accounts clerk profile updated.' };
        }
        if (action === 'admission_dashboard') {
            const admin = await requireAdmin();
            const [summaryRows, recent] = await Promise.all([
                this.result(client.rpc('get_admission_summary')),
                this.result(client.from('students').select('*').order('created_at', { ascending: false }).limit(8))
            ]);
            const summary = summaryRows[0] || { total_students: 0, male_students: 0, female_students: 0 };
            return {
                total_students: Number(summary.total_students),
                male_students: Number(summary.male_students),
                female_students: Number(summary.female_students),
                recent_students: recent, admin: admin.email, csrf_token: 'supabase-auth'
            };
        }
        if (action === 'students') {
            await requireAdmin();
            const rows = await this.result(client.from('students').select('*').order('last_name').order('first_name'));
            const search = (params.get('search') || '').toLocaleLowerCase();
            const gender = params.get('gender');
            return { students: rows.filter(row => (!gender || row.gender === gender) && (!search || `${row.admission_number} ${row.first_name} ${row.middle_name} ${row.last_name}`.toLocaleLowerCase().includes(search))) };
        }
        if (action === 'student') {
            await requireAdmin();
            return { student: await this.result(client.from('students').select('*').eq('id', params.get('id')).single()) };
        }
        if (action === 'register_student') {
            await requireAdmin();
            const student = await this.result(client.rpc('register_student', {
                p_first_name: data.first_name, p_middle_name: data.middle_name || '', p_last_name: data.last_name,
                p_gender: data.gender, p_date_of_birth: normalizedDate(data.date_of_birth), p_guardian_name: data.guardian_name,
                p_guardian_phone: data.guardian_phone, p_previous_school: data.previous_school,
                p_year_completed: Number(data.year_completed), p_certificate_name: data.certificate_name,
                p_index_number: data.index_number, p_marks_or_grade: data.marks_or_grade, p_class_completed: data.class_completed
            }));
            const row = Array.isArray(student) ? student[0] : student;
            return { message: 'Student registered.', admission_number: row.admission_number, student_id: row.id };
        }
        if (action === 'update_student') {
            await requireAdmin();
            const { id, ...record } = data;
            await this.result(client.from('students').update({
                ...record, year_completed: Number(record.year_completed), date_of_birth: normalizedDate(record.date_of_birth)
            }).eq('id', id));
            return { message: 'Student details updated.' };
        }
        if (action === 'remove_student') {
            await requireAdmin();
            await this.result(client.rpc('archive_student', { p_student_id: data.id, p_reason: data.reason }));
            return { message: 'Student archived and removed from the current register.' };
        }
        if (action === 'dashboard') {
            const [books, categories, profiles] = await Promise.all([
                this.result(client.rpc('list_public_books')),
                this.result(client.from('library_categories').select('*').order('name')),
                this.result(client.from('library_staff_profiles').select('*'))
            ]);
            const admin = user && await this.hasRole(client, user.id, 'admin');
            let loans;
            if (admin) loans = await this.result(client.from('loans').select('*,books(serial_number,title)').order('borrowed_at', { ascending: false }).limit(200));
            else loans = await this.result(client.rpc('list_public_loans'));
            const mappedLoans = loans.map(loan => ({
                ...loan, serial_number: loan.serial_number || loan.books?.serial_number,
                title: loan.title || loan.books?.title
            }));
            const categoryRows = categories.map(category => ({
                ...category, book_count: books.filter(book => book.category === category.name).length
            }));
            return {
                total_books: books.length, available_books: books.filter(book => book.available).length,
                borrowed_books: books.filter(book => !book.available).length,
                categories: categoryRows, books, loans: mappedLoans, staff: profiles.map(profilePhoto),
                admin: admin ? user.email : null, csrf_token: admin ? 'supabase-auth' : null
            };
        }
        if (action.startsWith('check')) {
            const serial = params.get('serial') || new URLSearchParams(inlineQuery).get('serial');
            const status = await this.result(client.rpc('check_book_status', { p_serial_number: serial }));
            if (!status.length) throw new Error('No book was found with that serial number.');
            const row = status[0];
            return { book: { ...row, borrowed_at: null, returned_at: null } };
        }
        if (action === 'category') {
            await requireAdmin();
            const result = await client.from('library_categories').insert({ name: data.name.trim() });
            if (result.error?.code === '23505') throw new Error('That category already exists.');
            if (result.error) throw result.error;
            return { message: 'Category added.' };
        }
        if (action === 'book') {
            await requireAdmin();
            if (!/^NSS\/\d{4}\/\d{3,}$/.test(data.serial_number.trim().toUpperCase())) {
                throw new Error('Use the serial format NSS/YYYY/001.');
            }
            const result = await client.from('books').insert({ ...data, category_id: Number(data.category_id), serial_number: data.serial_number.trim().toUpperCase() });
            if (result.error?.code === '23505') throw new Error('That serial number is already in use.');
            if (result.error) throw result.error;
            return { message: 'Book added.' };
        }
        if (action === 'borrow') {
            await requireAdmin();
            await this.result(client.rpc('record_book_loan', { p_book_id: Number(data.book_id), p_borrower_name: data.borrower_name, p_borrower_class: data.borrower_class || '' }));
            return { message: 'Borrowing recorded.' };
        }
        if (action === 'return') {
            await requireAdmin();
            await this.result(client.rpc('record_book_return', { p_loan_id: Number(data.loan_id) }));
            return { message: 'Return and clearance recorded.' };
        }
        if (action === 'staff') {
            const admin = await requireAdmin();
            const form = data;
            const old = await this.result(client.from('library_staff_profiles').select('*').eq('role', form.get('role')).maybeSingle());
            const image = await this.uploadPhoto(client, admin.id, form.get('photo'), 'library');
            const record = {
                role: form.get('role'), full_name: form.get('full_name').trim(), title: form.get('title').trim(),
                phone: form.get('phone').trim(), email: form.get('email').trim() || null,
                date_appointed: form.get('date_appointed') || null, details: form.get('details').trim(),
                photo_path: image || old?.photo_path || null
            };
            try { await this.result(client.from('library_staff_profiles').upsert(record, { onConflict: 'role' })); }
            catch (error) { if (image) await this.deletePhoto(client, image); throw error; }
            if (image && old?.photo_path) await this.deletePhoto(client, old.photo_path);
            return { message: 'Staff profile saved.' };
        }
        throw new Error(`Unsupported Supabase action: ${action}`);
    }
};
