const staffType = document.body.dataset.staffType;
let currentStaff = [];

function staffHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

async function loadPublicStaff() {
    const directory = document.getElementById('staff-directory');
    const status = document.getElementById('directory-status');
    try {
        const result = await (await window.schoolSupabase.client()).from('school_staff').select('*').eq('staff_type', staffType).order('full_name');
        if (result.error) throw result.error;
        const client = await window.schoolSupabase.client();
        currentStaff = (result.data || []).map(member => ({
            ...member,
            photo_path: window.schoolSupabase.photoUrl(client, member.photo_path)
        }));
        status.textContent = `${currentStaff.length} ${staffType === 'teaching' ? 'teacher' : 'staff member'}${currentStaff.length === 1 ? '' : 's'} listed.`;
        if (!currentStaff.length) {
            directory.innerHTML = '<p class="directory-empty">Staff profiles will appear here when they are added by the school administrator.</p>';
            return;
        }
        directory.innerHTML = currentStaff.map(member => {
            const image = member.photo_path
                ? `<img class="school-staff-photo" src="${staffHtml(member.photo_path)}" alt="Portrait of ${staffHtml(member.full_name)}">`
                : `<div class="school-staff-photo" role="img" aria-label="No profile photo for ${staffHtml(member.full_name)}">${staffHtml(member.full_name.trim().split(/\s+/).map(part => part[0]).slice(0, 2).join('').toUpperCase())}</div>`;
            const details = staffType === 'teaching'
                ? `<p class="school-staff-role">${staffHtml(member.leadership_position || 'Member')}${member.leadership_title ? ` · ${staffHtml(member.leadership_title)}` : ''}</p><p><strong>Subject(s):</strong> ${staffHtml(member.subjects)}</p>`
                : `<p class="school-staff-role">${staffHtml(member.work_type)}</p>`;
            return `<article class="school-staff-card">${image}<div class="school-staff-copy"><h3>${staffHtml(member.full_name)}</h3>${details}</div></article>`;
        }).join('');
    } catch (error) {
        status.textContent = 'Staff directory unavailable. Please try again later.';
        directory.innerHTML = '<p class="directory-empty">Staff records could not be loaded. Please try again later.</p>';
    }
}

function printStaffList() {
    if (!currentStaff.length) {
        window.alert('There are no staff records to print.');
        return;
    }
    if (!window.confirm('Do you want to print a hardcopy of this document?')) return;
    const teaching = staffType === 'teaching';
    const rows = currentStaff.map((member, index) => `<tr><td>${index + 1}</td><td>${staffHtml(member.full_name)}</td>${teaching
        ? `<td>${staffHtml(member.leadership_position || '')}${member.leadership_title ? ` · ${staffHtml(member.leadership_title)}` : ''}</td><td>${staffHtml(member.subjects)}</td>`
        : `<td>${staffHtml(member.work_type)}</td>`}</tr>`).join('');
    document.getElementById('staff-print-area').innerHTML = `<header class="school-print-header"><h1>Nyabikongori Senior School</h1><p>${teaching ? 'Teaching Staff Register' : 'Non-Teaching Staff Register'}</p></header><h2 class="school-print-title">${teaching ? 'Teaching staff' : 'Non-teaching staff'}</h2><p class="school-print-date">Printed: ${staffHtml(new Date().toLocaleDateString())}</p><table class="school-print-table"><thead><tr><th>No.</th><th>Full name</th>${teaching ? '<th>Leadership position</th><th>Subjects handled</th>' : '<th>Type of work</th>'}</tr></thead><tbody>${rows}</tbody></table>`;
    document.body.classList.add('staff-printing');
    window.print();
    window.setTimeout(() => document.body.classList.remove('staff-printing'), 500);
}

document.querySelector('.directory-print').addEventListener('click', printStaffList);
loadPublicStaff();
