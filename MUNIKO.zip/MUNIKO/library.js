const appState = { data: null, csrfToken: null };

const notice = document.querySelector('#app-notice');
const showNotice = (message, isError = false) => {
    notice.textContent = message;
    notice.classList.toggle('error', isError);
    notice.classList.add('visible');
};

async function request(action, { method = 'GET', data, formData = false } = {}) {
    return window.schoolSupabase.api(action, { method, data });
}

function escapeHtml(value = '') {
    return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[character]);
}

function formatDate(value, withTime = true, hour12 = true) {
    if (!value) return '—';
    const normalized = value.includes('T') ? value : value.replace(' ', 'T');
    const isoValue = /^\d{4}-\d{2}-\d{2}$/.test(normalized)
        ? `${normalized}T00:00:00+03:00`
        : `${normalized}${/Z|[+-]\d\d:\d\d$/.test(normalized) ? '' : '+03:00'}`;
    const date = new Date(isoValue);
    if (Number.isNaN(date.getTime())) return value;
    return new Intl.DateTimeFormat('en-GB', {
        day: '2-digit', month: 'long', year: 'numeric', weekday: 'long',
        ...(withTime ? { hour: '2-digit', minute: '2-digit', hour12 } : {}),
    }).format(date);
}

function renderDashboard(data) {
    appState.data = data;
    document.querySelector('#total-books').textContent = data.total_books;
    document.querySelector('#available-books').textContent = data.available_books;
    document.querySelector('#borrowed-books').textContent = data.borrowed_books;
    document.querySelector('#category-total').textContent = data.categories.length;

    const categoryList = document.querySelector('#category-list');
    categoryList.innerHTML = data.categories.length ? data.categories.map((category) =>
        `<article class="category-item"><span>${escapeHtml(category.name)}</span><strong>${category.book_count}</strong></article>`
    ).join('') : '<p class="empty-state">No categories have been added yet.</p>';

    const bookRows = document.querySelector('#book-rows');
    bookRows.innerHTML = data.books.length ? data.books.map((book) => `
        <tr data-book-row data-search="${escapeHtml(`${book.serial_number} ${book.title} ${book.author} ${book.category}`.toLowerCase())}">
            <td>${escapeHtml(book.serial_number)}</td>
            <td><span class="book-title">${escapeHtml(book.title)}</span><span class="book-author">${escapeHtml(book.author || 'Author not recorded')}</span></td>
            <td>${escapeHtml(book.category)}</td>
            <td><span class="availability ${book.available ? '' : 'out'}">${book.available ? 'Available' : 'Borrowed'}</span></td>
            <td>${book.available ? `<button class="row-action" data-check-serial="${escapeHtml(book.serial_number)}" type="button">Check status</button>` : 'On loan'}</td>
        </tr>`).join('') : '<tr><td class="empty-state" colspan="5">No books in the collection yet.</td></tr>';

    const loanRows = document.querySelector('#loan-rows');
    loanRows.innerHTML = data.loans.length ? data.loans.map((loan) => `
        <tr>
            <td><strong>${escapeHtml(loan.serial_number)}</strong><span class="book-author">${escapeHtml(loan.title)}</span></td>
            <td>${escapeHtml(loan.borrower_name)}</td><td>${escapeHtml(loan.borrower_class || '—')}</td>
            <td>${escapeHtml(formatDate(loan.borrowed_at))}</td><td>${escapeHtml(formatDate(loan.returned_at, true, false))}</td>
            <td>${loan.returned_at ? '<span class="availability">Cleared</span>' : `<button class="row-action" data-return-loan="${loan.id}" type="button">Record return</button>`}</td>
        </tr>`).join('') : '<tr><td class="empty-state" colspan="6">No borrowing records have been recorded.</td></tr>';

    const staffList = document.querySelector('#staff-list');
    const roles = [
        { key: 'head', label: 'Head of Library' },
        { key: 'council_leader', label: 'School Executive Council leader' },
    ];
    staffList.innerHTML = roles.map(({ key, label }) => {
        const profile = data.staff.find((item) => item.role === key);
        const photo = profile?.photo_path ? `<img class="staff-photo" src="${escapeHtml(profile.photo_path)}" alt="Portrait of ${escapeHtml(profile.full_name)}">` : '<div class="staff-photo" aria-hidden="true">NS</div>';
        return `<article class="staff-profile">${photo}<div><p class="staff-role">${label}</p><h3>${escapeHtml(profile?.full_name || 'Profile not yet added')}</h3><p>${escapeHtml(profile?.title || 'Appointed library staff')}</p>${profile?.phone ? `<p>${escapeHtml(profile.phone)}</p>` : ''}${profile?.email ? `<p>${escapeHtml(profile.email)}</p>` : ''}${profile?.date_appointed ? `<p>Appointed ${escapeHtml(formatDate(profile.date_appointed, false))}</p>` : ''}${profile?.details ? `<p>${escapeHtml(profile.details)}</p>` : ''}</div></article>`;
    }).join('');

    const categories = document.querySelector('#book-category');
    categories.innerHTML = data.categories.map((category) => `<option value="${category.id}">${escapeHtml(category.name)}</option>`).join('');
    if (!data.categories.length) categories.innerHTML = '<option value="">Add a category first</option>';
    const availableBooks = data.books.filter((book) => Boolean(book.available));
    document.querySelector('#borrow-book').innerHTML = availableBooks.length
        ? availableBooks.map((book) => `<option value="${book.id}">${escapeHtml(book.serial_number)} · ${escapeHtml(book.title)}</option>`).join('')
        : '<option value="">No available books</option>';

    appState.csrfToken = data.csrf_token || appState.csrfToken;
    updateAdminState(data.admin);
    document.querySelector('#staff-role').dispatchEvent(new Event('change'));
}

function updateAdminState(admin) {
    const signedIn = Boolean(admin);
    document.querySelector('#login-form').hidden = signedIn;
    document.querySelector('#admin-controls').hidden = !signedIn;
    const state = document.querySelector('#admin-state');
    state.textContent = signedIn ? `Signed in: ${admin}` : 'Signed out';
    state.classList.toggle('signed-in', signedIn);
}

async function loadDashboard() {
    try {
        renderDashboard(await request('dashboard'));
    } catch (error) {
        showNotice(`${error.message} Check the Supabase connection and run all SQL files under supabase/.`, true);
        document.querySelector('#category-list').innerHTML = '<p class="empty-state">The dashboard is waiting for the Supabase connection.</p>';
    }
}

async function submitForm(form, action, { multipart = false, success } = {}) {
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    try {
        const data = multipart ? new FormData(form) : Object.fromEntries(new FormData(form).entries());
        const result = await request(action, { method: 'POST', data, formData: multipart });
        showNotice(success || result.message || 'Saved.');
        form.reset();
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
    } finally {
        submitButton.disabled = false;
    }
}

document.querySelector('#book-search').addEventListener('input', (event) => {
    const query = event.target.value.trim().toLowerCase();
    document.querySelectorAll('[data-book-row]').forEach((row) => {
        row.hidden = !row.dataset.search.includes(query);
    });
});

document.querySelector('#book-rows').addEventListener('click', (event) => {
    const button = event.target.closest('[data-check-serial]');
    if (!button) return;
    document.querySelector('#serial-check').value = button.dataset.checkSerial;
    document.querySelector('#check-form').requestSubmit();
    document.querySelector('#check-book').scrollIntoView({ behavior: 'smooth' });
});

document.querySelector('#check-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const serial = document.querySelector('#serial-check').value.trim();
    const resultElement = document.querySelector('#lookup-result');
    resultElement.classList.remove('error');
    resultElement.textContent = 'Checking the register…';
    try {
        const result = await request(`check&serial=${encodeURIComponent(serial)}`);
        const book = result.book;
        resultElement.textContent = book.available
            ? `The book with serial number ${book.serial_number} is available to borrow.`
            : `The book with serial number ${book.serial_number} is currently on loan. Borrower details are available to authorized administrators.`;
    } catch (error) {
        resultElement.textContent = error.message;
        resultElement.classList.add('error');
    }
});

document.querySelector('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
        const result = await request('login', { method: 'POST', data: Object.fromEntries(new FormData(event.currentTarget).entries()) });
        appState.csrfToken = result.csrf_token;
        showNotice(`Signed in as ${result.admin}.`);
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#logout-button').addEventListener('click', async () => {
    try {
        await request('logout', { method: 'POST', data: {} });
        appState.csrfToken = null;
        showNotice('Signed out.');
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
    }
});

document.querySelector('#book-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(event.currentTarget, 'book', { success: 'Book added to the inventory.' });
});

document.querySelector('#category-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(event.currentTarget, 'category', { success: 'Category added; totals have been updated.' });
});

document.querySelector('#borrow-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(event.currentTarget, 'borrow', { success: 'Borrowing and current date/time recorded.' });
});

document.querySelector('#staff-form').addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(event.currentTarget, 'staff', { multipart: true, success: 'Staff profile saved.' });
});

document.querySelector('#loan-rows').addEventListener('click', async (event) => {
    const button = event.target.closest('[data-return-loan]');
    if (!button) return;
    button.disabled = true;
    try {
        const result = await request('return', { method: 'POST', data: { loan_id: Number(button.dataset.returnLoan) } });
        showNotice(`${result.message} Clearance date and time recorded.`);
        await loadDashboard();
    } catch (error) {
        showNotice(error.message, true);
        button.disabled = false;
    }
});

document.querySelector('#staff-role').addEventListener('change', (event) => {
    const profile = appState.data?.staff.find((item) => item.role === event.target.value);
    const form = document.querySelector('#staff-form');
    for (const field of ['full_name', 'title', 'phone', 'email', 'date_appointed', 'details']) {
        form.elements[field].value = profile?.[field] || '';
    }
});

document.querySelector('#staff-form').addEventListener('reset', () => {
    setTimeout(() => document.querySelector('#staff-role').dispatchEvent(new Event('change')), 0);
});

document.querySelectorAll('[data-print]').forEach((button) => {
    button.addEventListener('click', () => {
        const sectionMap = { books: '#inventory', loans: '#loans', staff: '#staff' };
        const targets = button.dataset.print === 'all' ? ['#inventory', '#loans', '#staff'] : [sectionMap[button.dataset.print]];
        document.querySelectorAll('.app-section').forEach((section) => section.classList.toggle('print-target', targets.includes(`#${section.id}`)));
        window.print();
        setTimeout(() => document.querySelectorAll('.app-section').forEach((section) => section.classList.remove('print-target')), 250);
    });
});

loadDashboard();