CREATE TABLE IF NOT EXISTS admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS library_categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS books (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    serial_number VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    author VARCHAR(140) NOT NULL DEFAULT '',
    category_id INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_books_category FOREIGN KEY (category_id)
        REFERENCES library_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_books_category (category_id)
);

CREATE TABLE IF NOT EXISTS loans (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    book_id INT UNSIGNED NOT NULL,
    borrower_name VARCHAR(140) NOT NULL,
    borrower_class VARCHAR(80) NOT NULL DEFAULT '',
    borrowed_at DATETIME NOT NULL,
    returned_at DATETIME NULL,
    CONSTRAINT fk_loans_book FOREIGN KEY (book_id)
        REFERENCES books(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_loans_book_status (book_id, returned_at),
    INDEX idx_loans_borrowed_at (borrowed_at)
);

CREATE TABLE IF NOT EXISTS staff_profiles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role ENUM('head', 'council_leader') NOT NULL UNIQUE,
    full_name VARCHAR(140) NOT NULL,
    title VARCHAR(140) NOT NULL DEFAULT '',
    phone VARCHAR(40) NOT NULL DEFAULT '',
    email VARCHAR(160) NULL,
    date_appointed DATE NULL,
    details TEXT NOT NULL,
    photo_path VARCHAR(255) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS school_staff (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    staff_type ENUM('teaching', 'non_teaching') NOT NULL,
    full_name VARCHAR(140) NOT NULL,
    photo_path VARCHAR(255) NULL,
    leadership_position ENUM('Staff Leader', 'Member') NULL,
    leadership_title VARCHAR(140) NULL,
    subjects VARCHAR(500) NULL,
    work_type VARCHAR(160) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_school_staff_type_name UNIQUE (staff_type, full_name),
    INDEX idx_school_staff_type_name (staff_type, full_name)
);

CREATE TABLE IF NOT EXISTS admission_sequences (
    admission_year SMALLINT UNSIGNED PRIMARY KEY,
    last_value INT UNSIGNED NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admission_number VARCHAR(24) NOT NULL UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    middle_name VARCHAR(80) NOT NULL DEFAULT '',
    last_name VARCHAR(80) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    date_of_birth DATE NULL,
    guardian_name VARCHAR(140) NOT NULL,
    guardian_phone VARCHAR(40) NOT NULL,
    previous_school VARCHAR(180) NOT NULL,
    year_completed SMALLINT UNSIGNED NOT NULL,
    certificate_name VARCHAR(140) NOT NULL,
    index_number VARCHAR(80) NOT NULL,
    marks_or_grade VARCHAR(80) NOT NULL,
    class_completed VARCHAR(80) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_students_name (last_name, first_name),
    INDEX idx_students_gender (gender)
);

CREATE TABLE IF NOT EXISTS removed_students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    admission_number VARCHAR(24) NOT NULL UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    middle_name VARCHAR(80) NOT NULL DEFAULT '',
    last_name VARCHAR(80) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    date_of_birth DATE NULL,
    guardian_name VARCHAR(140) NOT NULL,
    guardian_phone VARCHAR(40) NOT NULL,
    previous_school VARCHAR(180) NOT NULL,
    year_completed SMALLINT UNSIGNED NOT NULL,
    certificate_name VARCHAR(140) NOT NULL,
    index_number VARCHAR(80) NOT NULL,
    marks_or_grade VARCHAR(80) NOT NULL,
    class_completed VARCHAR(80) NOT NULL,
    reason ENUM('Dropped out', 'Completed school') NOT NULL,
    removed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_removed_at (removed_at)
);

CREATE TABLE IF NOT EXISTS accounts_clerk (
    id TINYINT UNSIGNED PRIMARY KEY,
    full_name VARCHAR(140) NOT NULL,
    email VARCHAR(160) NOT NULL,
    phone VARCHAR(40) NOT NULL,
    details TEXT NOT NULL,
    photo_path VARCHAR(255) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fee_payments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    receipt_number VARCHAR(40) NOT NULL UNIQUE,
    student_name VARCHAR(160) NOT NULL,
    admission_number VARCHAR(40) NOT NULL,
    form_grade VARCHAR(40) NOT NULL,
    amount_paid DECIMAL(12, 2) UNSIGNED NOT NULL,
    payment_method ENUM('Cash', 'M-Pesa', 'Bank', 'Cheque') NOT NULL DEFAULT 'Cash',
    payment_reference VARCHAR(100) NOT NULL DEFAULT '',
    paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    clerk_id TINYINT UNSIGNED NOT NULL,
    clerk_name VARCHAR(140) NOT NULL,
    CONSTRAINT fk_fee_payments_clerk FOREIGN KEY (clerk_id)
        REFERENCES accounts_clerk(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_fee_payments_admission (admission_number),
    INDEX idx_fee_payments_paid_at (paid_at),
    INDEX idx_fee_payments_student (student_name)
);

INSERT IGNORE INTO library_categories (name) VALUES
    ('Science'),
    ('Computer Science'),
    ('Fiction'),
    ('Reference');